"""Unit identity, then same-path BE step screening at phi=.01; no production edits."""
from pathlib import Path
import json,time,ctypes,hashlib,os
import numpy as np
from worker import Simulation,affinity
from noise import BrownianTape
ROOT=Path(__file__).resolve().parent;S=805306368.;N=64
cpus=affinity();pointer=ctypes.POINTER(ctypes.c_double)
def load(name):
 lib=ctypes.CDLL(str(ROOT/name));lib.wall_init.argtypes=[ctypes.c_int,ctypes.c_int];lib.wall_step.argtypes=[pointer,pointer,ctypes.c_double,pointer,pointer];assert lib.wall_init(6,0)==0
 return lib
def p(a):return a.ctypes.data_as(pointer)
def step(lib,h,drive,dt):
 out=np.empty_like(h);d=np.zeros(8);code=lib.wall_step(p(h),p(drive),dt,p(out),p(d))
 assert code==0 and np.isfinite(out).all() and out.min()>0 and d[3]<1e-8 and abs(out.mean()/.7-1)<1e-9,(code,d.tolist())
 return out,d
old=load('baseline.so');unit=load('wall_native.so');unit.wall_set_phi.argtypes=[ctypes.c_double];unit.wall_set_phi(.001)
h0=np.full((N,N),.7);h1=h0.copy();a=BrownianTape(61101,(2,N,N),base_dt=.03,depth=20);b=BrownianTape(61101,(2,N,N),base_dt=.03/S,depth=20)
errors=[];max_res=[0.,0.];begin=time.monotonic()
for i in range(128):
 start=i*a.width;end=(i+1)*a.width;dw=a.increment(start,end);du=b.increment(start,end)
 assert np.allclose(du,dw/np.sqrt(S),rtol=1e-13,atol=1e-18)
 h0,d0=step(old,h0,np.ascontiguousarray(dw/(2*.03)),.03)
 h1,d1=step(unit,h1,np.ascontiguousarray(du/((1/64)*(.03/S))),.03/S)
 errors.append(float(np.max(abs(h0-h1))));max_res=[max(max_res[0],d0[3]),max(max_res[1],d1[3])];a.commit(end);b.commit(end)
identity=dict(passed=max(errors)<1e-10,steps=128,phi=.001,max_field_difference=max(errors),max_full_BE_residual=max_res,seconds=time.monotonic()-begin,physical_cpus=cpus,unit_MG_equation_tolerance=.001*S,original_equation_tolerance=.001,same_physical_tolerances=True)
(ROOT/'identity.json').write_text(json.dumps(identity,indent=2));print('IDENTITY',json.dumps(identity),flush=True);assert identity['passed']
(ROOT/'runtime_gate.done').write_text('same-path unit identity passed; step screen still running\n')
cfg=json.loads((ROOT/'config.json').read_text());results=[];fields={};tau_end=1024*2.1e-9
for divisor in (64,8,2,1):
 tag='div%d'%divisor;sim=Simulation(cfg,ROOT/tag);cap=sim.noise.width//divisor;end=1024*sim.noise.width
 frames=[];frame_times=[];nextframe=16*sim.noise.width;begin=lastlog=time.monotonic();lastprogress=begin
 while sim.cursor<end and sim.status=='RUNNING':
  sim.proposal=min(sim.proposal,cap,end-sim.cursor);row=sim.advance()
  if sim.cursor==nextframe:
   frames.append(sim.h.copy());frame_times.append(sim.time);nextframe+=16*sim.noise.width
  now=time.monotonic()
  if now-lastlog>=45:
   sim.save();print('PROGRESS',json.dumps(dict(divisor=divisor,tau=sim.time,target=tau_end,hmin=row[2],accepted=sim.steps,rejected=sim.rejected,elapsed=now-begin)),flush=True);lastlog=now
 assert sim.status=='RUNNING' and sim.cursor==end,'Threshold or numerical limit before common comparison time'
 sim.save();fields[tag]=sim.h.copy()
 np.savez_compressed(ROOT/(tag+'_frames.npz'),h=np.array(frames),tau=np.array(frame_times))
 result=dict(divisor=divisor,tau=sim.time,dt_cap=2.1e-9/divisor,equivalent_old_code_dt=2.1e-9/divisor*S,steps=sim.steps,rejected=sim.rejected,hmin=float(sim.h.min()),hmax=float(sim.h.max()),rms=float(sim.h.std()),relative_mass=float(sim.h.mean()/.7-1),elapsed_wall_seconds=time.monotonic()-begin,kernel_seconds=sim.wall_total,wall_tau_per_second=sim.time/(time.monotonic()-begin),mean_full_step_wall_seconds=(time.monotonic()-begin)/sim.steps)
 results.append(result);print('CASE',json.dumps(result),flush=True)
reference=fields['div64'];rms=float(reference.std())
for row in results:
 h=fields['div%d'%row['divisor']];row['same_path_field_rms_error_over_reference_rms']=float(np.sqrt(np.mean((h-reference)**2))/rms);row['hmin_difference_vs_fine']=float(h.min()-reference.min());row['speedup_over_fine']=results[0]['elapsed_wall_seconds']/row['elapsed_wall_seconds'];row['short_screen_passed']=row['same_path_field_rms_error_over_reference_rms']<=.02 and abs(row['hmin_difference_vs_fine'])<=.005
passing=[row for row in results if row['short_screen_passed']];selected=min(passing,key=lambda row:row['divisor'])
report=dict(job=os.environ.get('SLURM_JOB_ID'),host=os.uname().nodename,identity=identity,phi=.01,slip=0,initial=.7,grid=64,noise_grid=64,seed=61101,comparison_tau=tau_end,results=results,screening_choice=selected,limits='One seed, short finite-time strong-error screen only. Not long-time equilibrium or first-passage convergence. A coordinate change alone does not reduce step count.',physical_cpus=cpus)
(ROOT/'trial_results.json').write_text(json.dumps(report,indent=2));print('RESULT',json.dumps(report),flush=True)
