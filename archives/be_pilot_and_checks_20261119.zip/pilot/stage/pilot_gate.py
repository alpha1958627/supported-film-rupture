from pathlib import Path
import json
import numpy as np
from worker import Simulation
root=Path.cwd();cfg=json.loads((root/'config.json').read_text())
s=Simulation(cfg,root/'gate')
for _ in range(3):s.advance()
s.save();s.advance();expected=s.h.copy()
r=Simulation(cfg,root/'gate');r.advance();error=float(np.max(abs(expected-r.h)))
assert error<1e-10
(root/'runtime_gate.done').write_text(json.dumps({'replay_max_field_error':error,'phi':cfg['phi'],'dt_divisor':cfg['dt_divisor'],'short_step_screen_passed':True}))
