#!/bin/bash
#SBATCH -p C64
#SBATCH -N 1
#SBATCH -n 16
#SBATCH -c 1
#SBATCH --mem=4G
#SBATCH --no-requeue
#SBATCH --open-mode=truncate
#SBATCH -J BMformal03
#SBATCH -t 0
#SBATCH -o /public/home/ljh/basilisk_midpoint_formal_20261025/formal-%A_%a.out
#SBATCH -e /public/home/ljh/basilisk_midpoint_formal_20261025/formal-%A_%a.err
#SBATCH --array=0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39
set -euo pipefail
source /etc/profile.d/dawning.sh
cd /public/home/ljh/basilisk_midpoint_formal_20261025
export BASILISK=/public/home/ljh/pnas_sharp_interface_20260812/basilisk/src
export CC99=/public/software/mpi/openmpi/gnu/4.0.3/bin/mpicc
export PATH="$BASILISK:/public/software/mpi/openmpi/gnu/4.0.3/bin:$PATH"
export PYTHONPATH=/public/home/ljh/ek_midpoint_gate_20261021_203853/wheel_site
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
python3 - <<'PY'
import hashlib,json
from pathlib import Path
for name,expected in json.loads(Path("formal_source_manifest.json").read_text()).items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==expected,name
PY
srun --cpu-bind=cores --mpi=pmix_v3 -n 16 python3 run_formal.py
