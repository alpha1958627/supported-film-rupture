#!/bin/bash
#SBATCH -p C64
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 1
#SBATCH --mem=8G
#SBATCH --no-requeue
#SBATCH --open-mode=truncate
#SBATCH -J BM-compile
#SBATCH -t 00:20:00
#SBATCH -w node9
#SBATCH -o /public/home/ljh/basilisk_midpoint_formal_20261025/BM-compile-%j.out
#SBATCH -e /public/home/ljh/basilisk_midpoint_formal_20261025/BM-compile-%j.err
set -euo pipefail
source /etc/profile.d/dawning.sh
cd /public/home/ljh/basilisk_midpoint_formal_20261025
export BASILISK=/public/home/ljh/pnas_sharp_interface_20260812/basilisk/src
export CC99=/public/software/mpi/openmpi/gnu/4.0.3/bin/mpicc
export PATH="$BASILISK:/public/software/mpi/openmpi/gnu/4.0.3/bin:$PATH"
export PYTHONPATH=/public/home/ljh/ek_midpoint_gate_20261021_203853/wheel_site
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
srun --mpi=pmix_v3 -n 1 python3 build_and_smoke.py
