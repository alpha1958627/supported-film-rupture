/* Native qcc trial backend for the frozen-mobility supported-film model.
   stdin: dt, N*N heights, optionally N*N standard normals; all doubles.
   stdout: status (0 success, 1 rejected), then candidate on success. */
#include "grid/multigrid.h"
#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#endif

scalar gap[];
static int n;
static double pi_value;
#include "gas_fft_2d.h"

int main (int argc, char ** argv)
{
  if (argc != 5)
    return 2;
#ifdef _WIN32
  _setmode(_fileno(stdin), _O_BINARY);
  _setmode(_fileno(stdout), _O_BINARY);
#endif
  n = atoi(argv[1]);
  const double length = atof(argv[2]), a = atof(argv[3]), theta = atof(argv[4]);
  if (n < 16 || n > 512 || (n & (n - 1)) || !(length > 0. && a > 0. && theta >= 0.))
    return 2;

  const int count = n*n;
  const double dx = length/n;
  pi_value = acos(-1.);
  size(length);
  periodic(right);
  periodic(top);
  init_grid(n);
  double * work = calloc(12*count, sizeof(double));
  if (!work)
    return 2;
  double * old = work, * re = old + count, * im = re + count;
  double * base_re = im + count, * base_im = base_re + count;
  double * p_re = base_im + count, * p_im = p_re + count;
  double * gain = p_im + count, * pressure = gain + count, * noise = pressure + count;
  double * mobility = noise + count, * rate = mobility + count;
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++) {
      int k = i*n + j, mx = i <= n/2 ? i : i-n, my = j <= n/2 ? j : j-n;
      double sx = sin(pi_value*mx/n), sy = sin(pi_value*my/n);
      double qd2 = 4.*(sx*sx + sy*sy)/(dx*dx);
      mobility[k] = qd2/3.;
      rate[k] = mobility[k]*(3.*a - qd2);
    }

  double dt, previous_dt = 0.;
  int exit_code = 0;
  while (fread(&dt, sizeof(double), 1, stdin) == 1) {
    if (!(dt > 0.) || fread(old, sizeof(double), count, stdin) != (size_t) count ||
        (theta > 0. && fread(p_re, sizeof(double), count, stdin) != (size_t) count)) {
      exit_code = 3;
      break;
    }
    double status = 1.;
    int valid = 1;
    if (dt != previous_dt) {
      for (int k = 0; k < count; k++) {
        double half = .5*dt*rate[k], denominator = 1. - half;
        valid &= denominator > 0.;
        gain[k] = (1. + half)/denominator;
        pressure[k] = -dt*mobility[k]/denominator;
        noise[k] = sqrt(2.*theta*mobility[k]*dt)/(dx*denominator);
      }
      if (valid)
        previous_dt = dt;
    }
    foreach (serial) {
      int k = (int) floor(x/dx)*n + (int) floor(y/dx);
      gap[] = old[k];
      re[k] = gap[] - 1.;
      im[k] = 0.;
    }
    if (valid) {
      if (theta > 0.) {
        memset(p_im, 0, count*sizeof(double));
        fft2(p_re, p_im, 0);
      }
      fft2(re, im, 0);
      for (int k = 0; k < count; k++) {
        base_re[k] = gain[k]*re[k] + (theta > 0. ? noise[k]*p_re[k] : 0.);
        base_im[k] = gain[k]*im[k] + (theta > 0. ? noise[k]*p_im[k] : 0.);
        re[k] = base_re[k];
        im[k] = base_im[k];
      }
      fft2(re, im, 1);
      for (int iter = 0; iter < 40; iter++) {
        for (int k = 0; k < count; k++) {
          double u = .5*(old[k] - 1. + re[k]), h = 1. + u;
          if (!(h > 0.) || !isfinite(h)) {
            valid = 0;
            break;
          }
          p_re[k] = a*u*u*(6. + u*(8. + 3.*u))/(h*h*h);
          p_im[k] = 0.;
        }
        if (!valid)
          break;
        fft2(p_re, p_im, 0);
        for (int k = 0; k < count; k++) {
          p_re[k] = base_re[k] + pressure[k]*p_re[k];
          p_im[k] = base_im[k] + pressure[k]*p_im[k];
        }
        fft2(p_re, p_im, 1);
        double change = 0.;
        for (int k = 0; k < count; k++) {
          valid &= isfinite(p_re[k]);
          change = fmax(change, fabs(p_re[k] - re[k]));
          re[k] = p_re[k];
        }
        if (!valid)
          break;
        if (change <= 1e-13) {
          for (int k = 0; k < count; k++) {
            old[k] = 1. + p_re[k];
            valid &= old[k] > 0.;
          }
          status = valid ? 0. : 1.;
          break;
        }
      }
    }
    if (fwrite(&status, sizeof(double), 1, stdout) != 1 ||
        (status == 0. && fwrite(old, sizeof(double), count, stdout) != (size_t) count) ||
        fflush(stdout)) {
      exit_code = 4;
      break;
    }
  }
  free(work);
  return exit_code;
}
