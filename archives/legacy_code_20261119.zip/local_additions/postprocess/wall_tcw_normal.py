"""No-slip wall TCW/normal-mode reference in the campaign's common h0,t* units.

Continuous time is retained in both branches. 'continuum128' uses physical
derivatives on the 128² observed Fourier modes; 'fv128' changes only spatial
symbols. Two-dimensional white-noise height variance needs this explicit
observation cutoff. There is no coarse-grid interpolation filter here.
"""
import numpy as np
from scipy.optimize import brentq

LENGTH = 128.
N_GRID = 128
ATTRACTION = (2*np.pi/LENGTH)**2/3


class WallTCW:
    def __init__(self, mean, kind='continuum128', n=N_GRID,
                 initial_unit_power=None, attraction=ATTRACTION, compute_switch=True):
        self.mean, self.kind, self.n, self.a = float(mean), kind, n, attraction
        indices = np.fft.fftfreq(n)*n
        radius2 = indices[:, None]**2+indices**2
        physical_q2 = (2*np.pi/LENGTH)**2*radius2
        if kind == 'continuum128':
            symbol = physical_q2
        elif kind == 'fv128':
            wave = 2*np.sin(np.pi*indices/n)/(LENGTH/n)
            symbol = wave[:, None]**2+wave**2
        else:
            raise ValueError(kind)
        mask = radius2 > 0
        self.symbol, representatives, inverse = np.unique(
            symbol[mask], return_index=True, return_inverse=True)
        self.weights = np.bincount(inverse).astype(float)
        self.q = np.sqrt(physical_q2[mask][representatives])
        mobility = mean**3*self.symbol/3
        self.g = mobility*(3*attraction/mean**4-self.symbol)
        self.d = self.weights*mobility/LENGTH**2
        self.omega = float(self.g.max())
        self.q_fast = float(self.q[np.argmax(self.g)])
        self.has_initial = initial_unit_power is not None
        if self.has_initial:
            assert initial_unit_power.shape == (n, n)
            self.initial = mean**2*np.bincount(inverse, weights=initial_unit_power[mask])
        else:
            self.initial = np.zeros_like(self.g)
        optimum = np.sqrt(3*attraction/(2*mean**4)) if attraction > 0 else 0.
        self.q_envelope = max(2*np.pi/LENGTH, optimum)
        self.omega_envelope = mean**3*self.q_envelope**2/3*(
            3*attraction/mean**4-self.q_envelope**2)
        self.switch = self._switch() if compute_switch and not self.has_initial else np.nan

    def variance(self, t, phi=1.):
        time = np.atleast_1d(np.asarray(t, dtype=float))
        assert np.all(time >= 0) and phi >= 0
        variance, derivative = np.empty_like(time), np.empty_like(time)
        for start in range(0, len(time), 96):
            times = time[start:start+96]
            x = 2*self.g[:, None]*times
            exponential = np.exp(x)
            integral = np.divide(np.expm1(x), self.g[:, None],
                out=np.broadcast_to(2*times, x.shape).copy(), where=abs(self.g[:, None]) > 1e-24)
            variance[start:start+96] = np.sum(
                self.initial[:, None]*exponential+phi*self.d[:, None]*integral, axis=0)
            derivative[start:start+96] = 2*np.sum(
                (self.g*self.initial+phi*self.d)[:, None]*exponential, axis=0)
        if np.ndim(t) == 0:
            return float(variance[0]), float(derivative[0])
        return variance, derivative

    def _switch(self):
        if self.omega <= 0:
            return np.nan
        def residual(t):
            v, dv = self.variance(t)
            return dv/(2*v)-self.omega
        times = np.geomspace(1e-12, 50/self.omega, 440)
        previous, before = times[0], residual(times[0])
        for time in times[1:]:
            after = residual(time)
            if before > 0 and after <= 0:
                return float(brentq(residual, previous, time, xtol=1e-9, rtol=1e-12))
            previous, before = time, after
        return np.nan

    def prediction(self, t, phi, crms=3.5):
        scalar = np.ndim(t) == 0
        time = np.atleast_1d(np.asarray(t, dtype=float))
        first = time <= self.switch if np.isfinite(self.switch) else np.ones(time.shape, dtype=bool)
        height = np.empty_like(time)
        if np.any(first):
            height[first] = self.mean-crms*np.sqrt(self.variance(time[first], phi)[0])
        if np.any(~first):
            amplitude = crms*np.sqrt(self.variance(self.switch, phi)[0])
            height[~first] = self.mean-amplitude*np.exp(self.omega*(time[~first]-self.switch))
        return float(height[0]) if scalar else height

    def event(self, phi, crms=3.5, threshold=.05):
        assert 0 < threshold < self.mean
        if not self.has_initial and phi == 0:
            return dict(time=np.inf, branch='flat without forcing')
        if np.isfinite(self.switch):
            amplitude = crms*np.sqrt(self.variance(self.switch, phi)[0])
            if amplitude < self.mean-threshold:
                return dict(time=float(self.switch+np.log((self.mean-threshold)/amplitude)/self.omega),
                            branch='TCW+normal')
            upper = self.switch
            branch = 'TCW only before threshold'
        else:
            upper = 1/max(self.omega, 1e-12)
            while self.prediction(upper, phi, crms) > threshold:
                upper *= 2
            branch = 'initial spectrum' if self.has_initial else 'TCW only'
        time = brentq(lambda t: self.prediction(t, phi, crms)-threshold,
                      0., upper, xtol=1e-8, rtol=1e-12)
        return dict(time=float(time), branch=branch)


def self_check(initial_unit_power):
    from pathlib import Path
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent/'jam'))
    from wall_film_2d import WallFilm2D
    results = []
    for r in (.5, .6, .7, .8, .9):
        model = WallTCW(r)
        spatial = WallTCW(r, 'fv128')
        solver = WallFilm2D(128, LENGTH/r, 8/r, ATTRACTION/r**2, .001/r**2)
        assert np.isclose(spatial.omega, np.max(solver.rate)/r, rtol=1e-12)
        assert model.omega <= model.omega_envelope*(1+1e-12)
        for time in (1., 100., 10000.):
            eps = 1e-5*max(1., time)
            fd = (model.variance(time+eps)[0]-model.variance(time-eps)[0])/(2*eps)
            assert np.isclose(fd, model.variance(time)[1], rtol=2e-7)
        assert np.isfinite(model.switch), r
        v, dv = model.variance(model.switch)
        assert np.isclose(dv/(2*v), model.omega, rtol=2e-10)
        for phi in (.0001, .001):
            event = model.event(phi)
            assert abs(model.prediction(event['time'], phi)-.05) < 1e-10
        initial = WallTCW(r, initial_unit_power=initial_unit_power)
        assert np.isclose(initial.variance(0., 0.)[0], (.01*r)**2, rtol=1e-10)
        event = initial.event(0.)
        assert abs(initial.prediction(event['time'], 0.)-.05) < 1e-9
        stable = WallTCW(r, attraction=0., compute_switch=False)
        exact = stable.weights/(LENGTH**2*stable.symbol)
        assert np.allclose(stable.d/(-stable.g), exact, rtol=1e-13)
        results.append(dict(ratio=r, omega=model.omega, q_fast=model.q_fast,
                            switch=model.switch, c1_slope_ratio=dv/(2*v)/model.omega,
                            fv_rate=spatial.omega, solver_rate=float(np.max(solver.rate)/r)))
    neutral = WallTCW(1., compute_switch=False)
    assert abs(neutral.omega) < 1e-18
    return dict(cases=results, stable_single_interface_factor_passed=True,
                zero_mode_excluded=True, parameters_fitted=0,
                ultraviolet_cutoff='128² observed Fourier modes, not an infinite-white-noise limit')
