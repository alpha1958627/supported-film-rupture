"""Continue hourly supported-film checkpoints within one Slurm allocation."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys


def publish(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2), encoding='utf-8')
    temporary.replace(path)


def continue_case(args):
    args.output.mkdir()
    previous = args.prior.resolve() if args.prior else None
    segment = 0
    driver = Path(__file__).resolve().with_name('run_rupture.py')
    while True:
        segment += 1
        target = args.output/('segment_{:06d}'.format(segment))
        publish(args.output/'current.json',
                dict(segment=segment, output=str(target),
                     checkpoint=str(previous) if previous else None,
                     started_utc=datetime.now(timezone.utc).isoformat()))
        command = [sys.executable, '-u', str(driver), str(args.executable.resolve()),
                   str(target), '--ratio', str(args.ratio), '--noise', args.noise,
                   '--theta', str(args.theta), '--wall', str(args.segment_wall),
                   '--until-rupture']
        if previous:
            command.extend(('--resume', str(previous)))
        process = subprocess.run(command)
        if not (target/'summary.json').exists():
            raise RuntimeError('No complete checkpoint after segment {}'.format(segment))
        result = json.loads((target/'summary.json').read_text(encoding='utf-8'))
        publish(args.output/'latest.json', dict(segment=segment, output=str(target), **result))
        print('CHECKPOINT {} phi={} ratio={} status={} t={} minima={}/{}'.format(
            segment, args.theta, args.ratio, result['status'], result['t_ref'],
            result['jam_hmin_h0'], result['basilisk_hmin_h0']), flush=True)
        if process.returncode:
            raise SystemExit(process.returncode)
        if result['status'] == 'threshold':
            return
        if result['status'] != 'wall_budget':
            raise RuntimeError('Unexpected continuation status '+result['status'])
        previous = target.resolve()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executable', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--ratio', type=float, choices=(.5, .6, .7, .8, .9), required=True)
    parser.add_argument('--theta', type=float, required=True)
    parser.add_argument('--noise', choices=('initial', 'thermal'), required=True)
    parser.add_argument('--prior', type=Path)
    parser.add_argument('--segment-wall', type=float, default=3600.)
    continue_case(parser.parse_args())
