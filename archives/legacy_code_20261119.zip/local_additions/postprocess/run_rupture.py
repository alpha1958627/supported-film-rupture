"""Paired supported-film continuation in units of the longest-wave critical thickness."""

import argparse
import csv
from functools import lru_cache
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
from time import perf_counter

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'jam'))
from wall_film_2d import WallFilm2D


class RunLimit(Exception):
    """An accepted state was saved before a test or wall-time boundary."""


def basilisk_trial(process, dt, h, white):
    process.stdin.write(struct.pack('<d', dt))
    process.stdin.write(h.astype('<f8', copy=False).tobytes())
    if white is not None:
        process.stdin.write(white.astype('<f8', copy=False).tobytes())
    process.stdin.flush()
    status = process.stdout.read(8)
    if len(status) != 8:
        raise RuntimeError('Basilisk trial protocol ended prematurely')
    if struct.unpack('<d', status)[0] == 1.:
        return None
    return np.frombuffer(process.stdout.read(h.size*8), dtype='<f8').reshape(h.shape)


def split_noise(white, rng):
    bridge = rng.standard_normal(white.shape)
    return (white + bridge)/np.sqrt(2.), (white - bridge)/np.sqrt(2.)


def run(args):
    n = 128
    length0, step0 = 128., args.dt
    ratio = args.ratio
    length = length0/ratio
    a0 = (2*np.pi/length0)**2/3
    a = a0/ratio**2
    theta0 = args.theta if args.noise == 'thermal' else 0.
    theta = theta0/ratio**2
    threshold = .05
    seed = 61100
    shape = (n, n)

    @lru_cache(maxsize=32)
    def film(level):
        return WallFilm2D(n, length, step0*2.**-level/ratio, attraction=a, theta=theta)

    rate = film(0).rate/ratio
    modes = np.unravel_index(np.argmax(rate), rate.shape)
    horizon = 20/float(rate[modes])
    initial = np.ones(shape)
    if args.noise == 'initial':
        perturb = np.random.default_rng(seed).standard_normal(shape)
        perturb -= perturb.mean()
        initial += .01*perturb/np.sqrt(np.mean(perturb**2))
    if args.probe:
        x = np.arange(n) - n//2
        well = np.exp(-(x[:, None]**2 + x**2)/8)
        well -= well.mean()
        initial = 1. - (1. - .051/ratio)*well/well.max()

    noise_rng = np.random.default_rng(seed + 1)
    jam = basilisk = initial
    last_above = {'jam': initial, 'basilisk': initial}
    t = 0.
    accepted = rejected = max_level = 0
    pair_error = 0.
    crossing = {}
    status = 'running'
    start = perf_counter()
    config = dict(grid=n, length_over_h0=length0, initial_over_h0=ratio,
                  threshold_over_h0=threshold, a_at_h0=a0, a_solver=a, theta_at_h0=theta0,
                  theta_solver=theta, seed=seed, thermal_seed=seed+1, noise=args.noise,
                  model='supported_no_slip',
                  initial_rms_over_initial=float(np.std(initial)), base_dt=step0,
                  max_rate=float(rate[modes]), fastest_index=list(map(int, modes)), horizon=horizon,
                  probe=args.probe, until_rupture=args.until_rupture,
                  mobility='frozen at the initial flat thickness')
    pending_noise = []
    pending_on_exit = []
    if args.resume:
        previous = json.loads((args.resume/'config.json').read_text())
        report = json.loads((args.resume/'summary.json').read_text())
        assert not args.probe
        for key in ('model', 'grid', 'length_over_h0', 'initial_over_h0', 'a_solver', 'theta_solver',
                    'base_dt', 'noise', 'seed', 'thermal_seed'):
            assert previous[key] == config[key], key
        assert report['status'] in ('pilot', 'wall_budget') or (
            report['status'] == 'numerical_failure' and len(report['crossing']) == 1)
        with np.load(str(args.resume/'fields.npz')) as archive:
            np.testing.assert_allclose(archive['initial'], ratio*initial, atol=1e-14, rtol=0)
            jam, basilisk = (archive[label + '_state'] if label + '_state' in archive
                             else archive[label + '_final']/ratio for label in ('jam', 'basilisk'))
            last_above = {label: archive[label + '_before']/ratio for label in ('jam', 'basilisk')}
            if 'rng_state' in report:
                levels = archive['pending_levels'].tolist()
                pending_noise = (list(zip(levels, archive['pending_white'])) if theta > 0. else
                                 [(level, None) for level in levels])
                noise_rng.bit_generator.state = report['rng_state']
        t, accepted, rejected, max_level = (report[key] for key in
                                            ('t_ref', 'accepted', 'rejected', 'max_level'))
        crossing = report['crossing'].copy()
        pair_error = report['max_paired_field_error_h0']
        config['resume_from'] = str(args.resume)
        if 'history_sha256' in report:
            with (args.resume/'history.csv').open('rb') as old_history:
                digest = hashlib.sha256()
                for block in iter(lambda: old_history.read(1024*1024), b''):
                    digest.update(block)
            assert digest.hexdigest() == report['history_sha256']
    start_accepted, start_t = accepted, t
    args.out.mkdir()
    (args.out/'config.json').write_text(json.dumps(config, indent=2))
    if args.resume:
        shutil.copyfile(str(args.resume/'history.csv'), str(args.out/'history.csv'))
    command = [str(args.exe.resolve()), str(n), str(length), str(a), str(theta)]
    with (args.out/'history.csv').open('a' if args.resume else 'w', newline='') as stream, subprocess.Popen(
            command, stdin=subprocess.PIPE, stdout=subprocess.PIPE) as process:
        history = csv.writer(stream)
        if not args.resume:
            history.writerow(('t_ref', 'dt_ref', 'jam_hmin_h0', 'basilisk_hmin_h0',
                              'jam_hmax_h0', 'basilisk_hmax_h0', 'pair_max_abs_h0'))

        def record(dt):
            history.writerow((t, dt, ratio*jam.min(), ratio*basilisk.min(), ratio*jam.max(),
                              ratio*basilisk.max(), ratio*np.max(abs(jam - basilisk))))

        def advance(level, white):
            nonlocal t, jam, basilisk, accepted, rejected, max_level, pair_error
            dt = step0*2.**-level
            if level > 36 or t + dt <= t:
                raise RuntimeError('time-step resolution exhausted')
            model = film(level)
            before = {'jam': jam, 'basilisk': basilisk}
            active = [label for label in before if label not in crossing]
            previous_min = ratio*min(before[label].min() for label in active)
            candidate_jam = jam
            if 'jam' in active:
                try:
                    with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
                        candidate_jam = model.advance(jam, white)
                except RuntimeError:
                    candidate_jam = None
            candidate_b = basilisk
            if candidate_jam is None or not np.isfinite(candidate_jam).all() or candidate_jam.min() <= 0.:
                candidate_b = None
            elif 'basilisk' in active:
                candidate_b = basilisk_trial(process, dt/ratio, basilisk, white)
            if candidate_b is not None:
                candidate = {'jam': candidate_jam, 'basilisk': candidate_b}
                minima = {label: ratio*candidate[label].min() for label in active}
                change = ratio*max(np.max(abs(candidate[label] - before[label])) for label in active)
                # Resolve the narrowing neck and the first threshold crossing.
                accept = (change <= .04*previous_min and min(minima.values()) >= threshold - 1e-4)
                if accept:
                    jam, basilisk = candidate_jam, candidate_b
                    for label, minimum in minima.items():
                        if minimum <= threshold:
                            last_above[label] = before[label]
                            crossing[label] = dict(t_before=t, t_after=t+dt, hmin_after=float(minimum))
                    t += dt
                    accepted += 1
                    max_level = max(max_level, level)
                    pair_error = max(pair_error, float(ratio*np.max(abs(jam - basilisk))))
                    if max(abs(jam.mean()-1.), abs(basilisk.mean()-1.)) > 2e-12:
                        raise RuntimeError('film volume drift')
                    record(dt)
                    if len(crossing) == 2:
                        return True
                    completed = accepted - start_accepted
                    if args.pilot_steps and completed >= args.pilot_steps:
                        raise RunLimit('pilot')
                    if args.pilot_time and t - start_t >= args.pilot_time:
                        raise RunLimit('pilot')
                    if completed % 250 == 0 and perf_counter() - start >= args.wall:
                        raise RunLimit('wall_budget')
                    if completed % 1500 == 0:
                        stream.flush()
                        print('t={:.8g} min={:.8g} dt={:.6g} accepted={} rejected={} wall={:.1f}s'.format(
                            t, ratio*min(jam.min(), basilisk.min()), dt, accepted, rejected,
                            perf_counter()-start), flush=True)
                    return False
            rejected += 1
            if white is None:
                left = right = None
            else:
                left, right = split_noise(white, noise_rng)
            try:
                crossed = advance(level + 1, left)
            except RunLimit:
                pending_on_exit.append((level + 1, right))
                raise
            return crossed or advance(level + 1, right)

        if not args.resume:
            record(0.)
        try:
            print(json.dumps(config), flush=True)
            crossed = False
            for index, (level, white) in enumerate(pending_noise):
                try:
                    crossed = advance(level, white)
                except RunLimit:
                    pending_on_exit.extend(pending_noise[index+1:])
                    raise
                if crossed:
                    break
            if crossed:
                status = 'threshold'
            else:
                roots = itertools.count() if args.until_rupture else range(
                    int(np.ceil((horizon-t)/step0)) if not args.probe else 3)
                for root in roots:
                    white = noise_rng.standard_normal(shape) if theta > 0 else None
                    if advance(0, white):
                        status = 'threshold'
                        break
                    if (root + 1) % 2500 == 0:
                        stream.flush()
                        print('t={:.8g} min={:.8g} accepted={} rejected={} wall={:.1f}s'.format(
                            t, ratio*min(jam.min(), basilisk.min()), accepted, rejected,
                            perf_counter()-start), flush=True)
                else:
                    status = 'probe_no_crossing' if args.probe else 'horizon'
        except RunLimit as limit:
            status = str(limit)
        except Exception as exc:
            status = 'numerical_failure'
            print(repr(exc), file=sys.stderr, flush=True)
        finally:
            process.stdin.close()
            code = process.wait()
            if code != 0:
                status = 'backend_failure'
            stream.flush()
            os.fsync(stream.fileno())
            digest = hashlib.sha256()
            with (args.out/'history.csv').open('rb') as saved_history:
                for block in iter(lambda: saved_history.read(1024*1024), b''):
                    digest.update(block)
            result = dict(status=status, t_ref=t, jam_hmin_h0=float(ratio*jam.min()),
                          basilisk_hmin_h0=float(ratio*basilisk.min()), crossing=crossing,
                          accepted=accepted, rejected=rejected, max_level=max_level,
                          max_paired_field_error_h0=pair_error, wall_seconds=perf_counter()-start,
                          rng_state=noise_rng.bit_generator.state, history_sha256=digest.hexdigest())
            pending_white = np.asarray([white for _, white in pending_on_exit]) if theta > 0. else np.empty((0, n, n))
            np.savez_compressed(str(args.out/'fields.npz'), initial=ratio*initial,
                                jam_state=jam, basilisk_state=basilisk,
                                pending_levels=np.array([level for level, _ in pending_on_exit], dtype=int),
                                pending_white=pending_white,
                                jam_final=ratio*jam, basilisk_final=ratio*basilisk,
                                jam_before=ratio*last_above['jam'], basilisk_before=ratio*last_above['basilisk'],
                                x=(np.arange(n) + .5)*length0/n)
            (args.out/'summary.json').write_text(json.dumps(result, indent=2, allow_nan=False))
            print(json.dumps(result), flush=True)
    return 0 if status in ('threshold', 'pilot', 'wall_budget') else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('exe', type=Path)
    parser.add_argument('out', type=Path)
    parser.add_argument('--ratio', type=float, choices=(.5, .6, .7, .8, .9), required=True)
    parser.add_argument('--noise', choices=('thermal', 'initial'), required=True)
    parser.add_argument('--dt', type=float, default=8.)
    parser.add_argument('--theta', type=float, default=1e-4)
    parser.add_argument('--pilot-time', type=float, default=0.)
    parser.add_argument('--pilot-steps', type=int, default=0)
    parser.add_argument('--wall', type=float, default=4700.)
    parser.add_argument('--until-rupture', action='store_true')
    parser.add_argument('--probe', action='store_true')
    parser.add_argument('--resume', type=Path, help='Committed checkpoint from a previous segment')
    args = parser.parse_args()
    if not np.isfinite([args.theta, args.dt]).all() or args.dt <= 0. or args.theta < 0.:
        parser.error('theta must be nonnegative and dt must be positive and finite')
    if args.noise == 'thermal' and args.theta == 0.:
        parser.error('thermal forcing requires positive theta')
    sys.exit(run(args))
