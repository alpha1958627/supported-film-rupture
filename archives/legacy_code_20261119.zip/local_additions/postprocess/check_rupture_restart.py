"""Check Brownian and deterministic restart paths and synthetic threshold crossings."""

import argparse
import json
from pathlib import Path
import subprocess
import sys

import numpy as np


def verify(executable, output):
    output.mkdir(parents=True)
    driver = Path(__file__).resolve().with_name('run_rupture.py')
    checks = {}
    for name, theta, noise in (('initial', 0., 'initial'),
                                ('phi0.0001', 1e-4, 'thermal'),
                                ('phi0.001', 1e-3, 'thermal')):
        common = [sys.executable, str(driver), str(executable.resolve()),
                  '--ratio', '.9', '--noise', noise, '--theta', str(theta)]
        direct, part, resumed = (output/(name+'_'+suffix)
                                 for suffix in ('direct', 'part', 'resumed'))
        for target, steps, prior in ((direct, 20, None), (part, 7, None), (resumed, 13, part)):
            command = common[:3]+[str(target)]+common[3:]+['--pilot-steps', str(steps)]
            if prior:
                command.extend(('--resume', str(prior)))
            subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
        assert (direct/'history.csv').read_bytes() == (resumed/'history.csv').read_bytes()
        with np.load(str(direct/'fields.npz')) as first, np.load(str(resumed/'fields.npz')) as second:
            for key in ('jam_state', 'basilisk_state', 'pending_levels', 'pending_white'):
                np.testing.assert_array_equal(first[key], second[key])
        a = json.loads((direct/'summary.json').read_text())
        b = json.loads((resumed/'summary.json').read_text())
        for key in ('t_ref', 'accepted', 'rejected', 'rng_state', 'history_sha256'):
            assert a[key] == b[key], key
        probe = output/(name+'_probe')
        command = common[:3]+[str(probe)]+common[3:]+['--probe']
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
        case = json.loads((probe/'config.json').read_text())
        result = json.loads((probe/'summary.json').read_text())
        assert case['model'] == 'supported_no_slip'
        assert np.isclose(3*case['a_at_h0'], (2*np.pi/128)**2)
        assert result['status'] == 'threshold' and len(result['crossing']) == 2
        for solver in ('jam', 'basilisk'):
            event = result['crossing'][solver]
            assert event['t_after'] > event['t_before']
            assert .0499 <= event['hmin_after'] <= .05
        checks[name] = dict(restart_exact=True, probe_threshold=True,
                            direct_time=a['t_ref'], probe_crossing=result['crossing'])
        print(name, 'restart and synthetic crossing passed', flush=True)
    (output/'checks.json').write_text(json.dumps(checks, indent=2), encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executable', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    verify(args.executable, args.output)
