#!/bin/bash
#SBATCH --job-name=wall-rupture-check
#SBATCH --partition=C72
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --time=00:05:00
#SBATCH --output=preflight-%j.log
set -euo pipefail
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export BASILISK=/public/software/apps/basilisk/src
python=/public/home/ljh/jam_newtonian_20261028_095400/env/bin/python
printf 'START=%s HOST=%s\n' "$(TZ=Asia/Shanghai date -Is)" "$(hostname)"
sha256sum basilisk/wall_trial.c basilisk/gas_fft_2d.h jam/wall_film_2d.py \
    postprocess/run_rupture.py postprocess/continue_case.py postprocess/check_rupture_restart.py > source_sha256.txt
(
    cd basilisk
    "$BASILISK/qcc" -O3 -disable-dimensions wall_trial.c -o ../build/wall_trial -lm
)
"$python" -u postprocess/check_rupture_restart.py build/wall_trial preflight
printf 'FINISH=%s\n' "$(TZ=Asia/Shanghai date -Is)"
