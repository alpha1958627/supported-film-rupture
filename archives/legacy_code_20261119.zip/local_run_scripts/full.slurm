#!/bin/bash
#SBATCH --job-name=wall-h-phi
#SBATCH --partition=C72
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --time=UNLIMITED
#SBATCH --array=0-14
#SBATCH --output=logs/full-%A_%a.log
set -euo pipefail
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
python=/public/home/ljh/jam_newtonian_20261028_095400/env/bin/python
test -s preflight/checks.json
test -x build/wall_trial
sha256sum -c source_sha256.txt
printf 'START=%s HOST=%s INDEX=%s\n' "$(TZ=Asia/Shanghai date -Is)" "$(hostname)" "$SLURM_ARRAY_TASK_ID"
"$python" -u - "$SLURM_ARRAY_TASK_ID" <<'PY'
import json
from pathlib import Path
import subprocess
import sys
case=json.loads(Path('cases.json').read_text())[int(sys.argv[1])]
print(json.dumps(case), flush=True)
command=[sys.executable,'-u','postprocess/continue_case.py','build/wall_trial',
         'cases/'+case['name'],'--ratio',str(case['ratio']),'--theta',str(case['theta']),
         '--noise',case['noise']]
raise SystemExit(subprocess.call(command))
PY
printf 'FINISH=%s\n' "$(TZ=Asia/Shanghai date -Is)"
