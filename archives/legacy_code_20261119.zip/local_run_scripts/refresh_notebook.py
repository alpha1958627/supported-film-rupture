"""Refresh the reviewed notebook transactionally with a verified local snapshot."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import shutil
import time

import nbformat
from nbclient import NotebookClient

RUN = Path(__file__).resolve().parent
REPO = RUN.parents[1]
CANONICAL = REPO / 'postprocess/附壁液膜.ipynb'
STAMP = '20261112T082236Z'
DATA = RUN / ('plot_snapshot_' + STAMP)
OUTPUT = RUN / ('notebook_exports_' + STAMP)
snapshot = json.loads((DATA / 'snapshot.json').read_text())
completed = sum(c['checkpoint']['status'] == 'threshold' for c in snapshot['cases'])
prior_sha = hashlib.sha256(CANONICAL.read_bytes()).hexdigest()
OUTPUT.mkdir(exist_ok=True)
backup = OUTPUT / '附壁液膜_更新前.ipynb'
assert not backup.exists(), 'This refresh already has a backup; inspect it before rerunning.'
shutil.copyfile(CANONICAL, backup)
nb = nbformat.read(CANONICAL, as_version=4)
original_model = nb.cells[30].source

nb.cells[0].source = f'''# 附壁液膜

使用北京时间 **2026-11-12 16:22:36** 的最新固定快照重画：15组成对Python/FFT与Basilisk C轨迹，
**{completed}组已破碎，{15-completed}组仍在观察**。保留原来的坐标、线性/对数尺度和图面格式。

预测沿用11月11日14:54数据版本的固定 $C_{{\\rm rms}}=3.5$ 方法，**没有重新拟合**；
15组阈值预测与161点厚度预测曲线均逐项对照昨日保存值。原始快照与更新前Notebook保留。
打开即可查看已执行的历史、首达/下界与预测对照；下面的计算和绘图代码均可编辑复算。'''
nb.cells[3].source = nb.cells[3].source.replace(
    "SNAPSHOT_NAME = 'plot_snapshot_20261111T065404Z'",
    "SNAPSHOT_NAME = 'plot_snapshot_" + STAMP + "'").replace(
    "EXPORT_DIR = REPO/'runs'/RUN_NAME/'notebook_exports'",
    "EXPORT_DIR = REPO/'runs'/RUN_NAME/'notebook_exports_" + STAMP + "'")
nb.cells[25].source = nb.cells[25].source.replace('plot_snapshot_20261111T065404Z', DATA.name)
nb.cells[26].source = nb.cells[26].source.replace(
    '数据仍是前面同一份14:54快照，未来段是参考模型外推。',
    '观测数据更新为上面的11月12日16:22快照；预测参数与昨日完全一致。\n'
    '虚线/参考两段是原预测，新增观测用于检验它；未破碎项仍只报告下界。')

# All prediction parameters and the model implementation are kept unchanged.
baseline = RUN / 'prediction/events.csv'
baseline_dense = RUN / 'prediction/dense.csv'
nb.cells[32].source += '''

# Freeze the previous forecast; compare new observations without fitting again.
BASELINE = REPO/'runs'/RUN_NAME/'prediction'
with (BASELINE/'events.csv').open(encoding='utf-8') as stream:
    prior_events = {(float(r['ratio']), float(r['phi'])): r for r in csv.DictReader(stream)}
forecast_keys = ['predicted_t_'+str(target) for target in (.3, .2, .1, .05)]
forecast_keys += ['omega', 'q_fast', 'fv_predicted_t_0.05']
for row in prediction_result['events']:
    prior = prior_events[(row['ratio'], row['phi'])]
    assert row['crms'] == float(prior['crms']) == 3.5
    for key in forecast_keys:
        np.testing.assert_allclose(row[key], float(prior[key]), rtol=2e-12, atol=1e-12)
    assert row['branch'] == prior['branch']
    if row['switch'] is not None:
        np.testing.assert_allclose(row['switch'], float(prior['switch']), rtol=2e-12)
with (BASELINE/'dense.csv').open(encoding='utf-8') as stream:
    prior_dense = list(csv.DictReader(stream))
assert len(prior_dense) == len(prediction_result['dense']) == 161
for actual, prior in zip(prediction_result['dense'], prior_dense):
    for key in ('ratio', 'initial', 'phi0001', 'phi001'):
        np.testing.assert_allclose(actual[key], float(prior[key]), rtol=2e-12, atol=1e-12)
prediction_result['validation'].update(
    crms=CRMS, snapshot_utc=snapshot['ended_utc'],
    unchanged_previous_case_predictions=len(prior_events), unchanged_dense_points=161,
    baseline_events_sha256=hashlib.sha256((BASELINE/'events.csv').read_bytes()).hexdigest(),
    baseline_dense_sha256=hashlib.sha256((BASELINE/'dense.csv').read_bytes()).hexdigest())
display(Markdown('**原预测核对通过：15组阈值预测及161点厚度曲线均保持不变；只更新实测输入。**'))
'''
nb.cells[34].source = nb.cells[34].source.replace(
    '预测0.3', '原预测0.3').replace('预测0.2', '原预测0.2').replace(
    '预测0.1', '原预测0.1').replace('预测0.05', '原预测0.05')
nb.cells[35].source = nb.cells[35].source.replace(
    "end = target if phi == 0 else min(target, float(native['time'][-1]))",
    "end = target if phi == 0 or native['record']['event_observed'] else min(target, float(native['time'][-1]))"
).replace("method = 'Initial spectrum' if phi == 0 else 'TCW + mode'",
          "method = 'Prior prediction'").replace("label='Reference'", "label='Prior prediction'")
nb.cells[35].source = nb.cells[35].source.replace(
    "if row['event_observed']:\n                    ax.plot(row['t_r']",
    "if row['event_observed']:\n                    times.append(row['t_r'])\n                    ax.plot(row['t_r']")
nb.cells[36].source += '\n\n预测线来自昨日固定模型，圈/点与下界更新为最新快照。'
nb.cells[44].source += '\n\n两段参考均保持原预测；实际点更新至最新首达或观察终点。'
nb.cells[46].source += '\n\n两段参考均保持原预测；实际点更新至最新首达或观察终点。'
nb.cells[49].source = nb.cells[49].source.replace(
    "'这不证明模拟形态已成为单模。热组尚无实测破碎时间，最终寿命仍待后期轨迹检验。'))",
    "'这不证明模拟形态已成为单模。'))\n"
    "thermal_known = [r for r in thermal_events if r['observed_t_r'] is not None]\n"
    "display(Markdown(f'热组已有{len(thermal_known)}组实测首达、{len(thermal_events)-len(thermal_known)}组仍删失；'\n"
    "                 '下界不能当作破碎时间，也不由事件子集估集合平均。'))\n"
    "if thermal_known:\n"
    "    display(Markdown('新增热组检验：'+ '；'.join(\n"
    "        f'phi={r[\"phi\"]:g}、hi/h0={r[\"ratio\"]:.1f}：原预测偏晚{r[\"predicted_time_error_percent\"]:.2f}%'\n"
    "        for r in thermal_known)))")
nb.metadata['wall_film_snapshot'] = snapshot['ended_utc']
nb.metadata['wall_data_refresh'] = dict(
    prior_notebook_sha256=prior_sha, snapshot=DATA.name,
    baseline_events_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),
    baseline_dense_sha256=hashlib.sha256(baseline_dense.read_bytes()).hexdigest(),
    comparison='previous forecast kept fixed; only observation data refreshed')
assert nb.cells[30].source == original_model
assert 'CRMS = 3.5' in nb.cells[29].source
assert '热组尚无实测破碎时间' not in nb.cells[49].source
for cell in nb.cells:
    if cell.cell_type == 'code':
        cell.outputs = []
        cell.execution_count = None
nbformat.validate(nb)
candidate = OUTPUT / '附壁液膜_候选.ipynb'
nbformat.write(nb, candidate)

if os.name == 'nt':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
started = time.perf_counter()
client = NotebookClient(nb, timeout=1800, kernel_name='python3',
                        resources={'metadata': {'path': str(REPO)}})
try:
    client.execute()
finally:
    nbformat.write(nb, candidate)
code = [c for c in nb.cells if c.cell_type == 'code']
assert all(c.execution_count is not None for c in code)
assert not [o for c in code for o in c.outputs if o.output_type == 'error']
figures = sum('image/png' in o.get('data', {}) for c in code for o in c.outputs)
assert figures == 12
assert hashlib.sha256(CANONICAL.read_bytes()).hexdigest() == prior_sha
os.replace(candidate, CANONICAL)
receipt = dict(notebook=str(CANONICAL), snapshot=DATA.name,
               snapshot_utc=snapshot['ended_utc'], code_cells=len(code),
               embedded_figures=figures, errors=0,
               execution_seconds=time.perf_counter()-started,
               notebook_sha256=hashlib.sha256(CANONICAL.read_bytes()).hexdigest(),
               prior_notebook_sha256=prior_sha, output=str(OUTPUT))
(OUTPUT/'notebook_validation.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
(RUN/'plot_data_path.txt').write_text(str(DATA), encoding='utf-8')
print(json.dumps(receipt, indent=2))
