"""Apply the linked chat's fixed-C TCW/normal matching to the wall snapshot."""
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO/'postprocess'))
from wall_tcw_normal import WallTCW, self_check
import plot_progress as base

CRMS = 3.5
RATIOS = (.5, .6, .7, .8, .9)
COLORS = base.COLORS
MARKERS = base.MARKERS
GROUPS = base.GROUPS


def export_csv(path, rows):
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def analyze(cases, data):
    unit = None
    for case in cases:
        if case['noise'] != 'initial':
            continue
        with np.load(data/'cases'/case['name']/'checkpoint_fields.npz') as z:
            pattern = (z['initial']-case['ratio'])/case['ratio']
        if unit is None:
            unit = pattern
        else:
            np.testing.assert_allclose(pattern, unit, rtol=0, atol=2e-14)
    initial_power = abs(np.fft.fft2(unit)/128**2)**2
    checks = self_check(initial_power)
    models, fv_models, events, scores, fields, curves = {}, {}, [], [], [], []
    for case in cases:
        r, phi = case['ratio'], case['theta']
        initial = initial_power if phi == 0 else None
        model = WallTCW(r, initial_unit_power=initial)
        spatial = WallTCW(r, 'fv128', initial_unit_power=initial)
        models[(r, phi)], fv_models[(r, phi)] = model, spatial
        row = dict(ratio=r, phi=phi, crms=CRMS, omega=model.omega,
                   q_fast=model.q_fast, switch=model.switch if np.isfinite(model.switch) else None,
                   switch_height=model.prediction(model.switch, phi, CRMS) if np.isfinite(model.switch) else None,
                   observed_until=float(case['records']['basilisk']['time'][-1]))
        for target in (.3, .2, .1, .05):
            event = model.event(phi, CRMS, target)
            row['predicted_t_'+str(target)] = event['time']
        row['branch'] = model.event(phi, CRMS)['branch']
        row['fv_predicted_t_0.05'] = spatial.event(phi, CRMS)['time']
        actual = case['records']['basilisk']['record']
        row['observed_t_r'] = actual['t_r']
        row['predicted_time_error_percent'] = (100*(row['predicted_t_0.05']/actual['t_r']-1)
                                                 if actual['event_observed'] else None)
        row['observation_outlives_forecast'] = bool(not actual['event_observed'] and
                                                       row['observed_until'] >= row['predicted_t_0.05'])
        events.append(row)
        time, observed = (case['records']['basilisk'][name] for name in ('time', 'height'))
        last = min(float(time[-1]), row['predicted_t_0.05'])
        grid = np.unique(np.r_[0., np.geomspace(1e-8, last, 800), np.linspace(0., last, 2200), last])
        prediction, fv_prediction = model.prediction(grid, phi, CRMS), spatial.prediction(grid, phi, CRMS)
        for t, h, hfv in zip(grid, prediction, fv_prediction):
            curves.append(dict(ratio=r, phi=phi, time=float(t), hmin_reference=float(h),
                               hmin_fv_space=float(hfv), window='observed'))
        selected = time <= last
        t, truth = time[selected], observed[selected]
        error = np.interp(t, grid, prediction)-truth
        fv_error = np.interp(t, grid, fv_prediction)-truth
        queries = np.unique(np.r_[np.geomspace(1e-7, last, 80), np.linspace(0., last, 80)])
        interpolation_error = float(np.max(abs(model.prediction(queries, phi, CRMS)-np.interp(queries, grid, prediction))))
        assert interpolation_error < 2e-5, (r, phi, interpolation_error)
        scores.append(dict(ratio=r, phi=phi, compared_until=float(t[-1]),
                           time_RMSE=float(np.sqrt(np.trapezoid(error**2, t)/t[-1])),
                           time_bias=float(np.trapezoid(error, t)/t[-1]),
                           fv_time_RMSE=float(np.sqrt(np.trapezoid(fv_error**2, t)/t[-1])),
                           reference_interpolation_max_abs=interpolation_error))
        cp = case['checkpoint']
        field_time = cp['crossing'].get('basilisk', {}).get('t_after', cp['t_ref'])
        with np.load(data/'cases'/case['name']/'checkpoint_fields.npz') as z:
            field = z['basilisk_final']
        rms = float(field.std())
        sigma_ref = float(np.sqrt(model.variance(field_time, phi)[0]))
        sigma_fv = float(np.sqrt(spatial.variance(field_time, phi)[0]))
        fields.append(dict(ratio=r, phi=phi, time=field_time, checkpoint_container_time=cp['t_ref'], measured_rms=rms,
                           measured_hmin=float(field.min()), measured_crms=(r-float(field.min()))/rms,
                           linear_spectrum_rms=sigma_ref, fv_linear_spectrum_rms=sigma_fv,
                           matched_reference_rms=(r-model.prediction(field_time, phi, CRMS))/CRMS,
                           linear_rms_relative_error=sigma_ref/rms-1,
                           fv_linear_rms_relative_error=sigma_fv/rms-1))
    dense = []
    for r in np.linspace(.5, .9, 161):
        thermal = WallTCW(r)
        deterministic = WallTCW(r, initial_unit_power=initial_power)
        dense.append(dict(ratio=float(r), initial=deterministic.event(0., CRMS)['time'],
                          phi0001=thermal.event(.0001, CRMS)['time'],
                          phi001=thermal.event(.001, CRMS)['time']))
    checks['dense_curve_max_relative_step'] = {}
    for key in ('initial', 'phi0001', 'phi001'):
        values = np.array([row[key] for row in dense])
        assert np.all(np.isfinite(values)) and np.all(np.diff(values) > 0)
        jump = float(np.max(np.diff(values)/values[:-1]))
        assert jump < .08, (key, jump)
        checks['dense_curve_max_relative_step'][key] = jump
    return dict(models=models, fv_models=fv_models, events=events, scores=scores,
                field_checks=fields, curves=curves, dense=dense, validation=checks)


def legend_thickness(fig):
    handles = [Line2D([], [], color=c, marker=m, markerfacecolor='white',
                      label=rf'$h_{{\rm i}}/h_0={r}$') for r, c, m in zip(RATIOS, COLORS, MARKERS)]
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.56, .995),
               ncols=3, columnspacing=.8, handlelength=1.2, handletextpad=.3, labelspacing=.15)


def overlay(cases, result, group, out, book):
    phi, title, stem = group
    fig, ax = plt.subplots()
    fig.subplots_adjust(left=.16, right=.96, bottom=.29, top=.75)
    group_cases = sorted((c for c in cases if c['theta'] == phi), key=lambda c: c['ratio'])
    for case, color, marker in zip(group_cases, COLORS, MARKERS):
        r = case['ratio']
        native, python = case['records']['basilisk'], case['records']['jam']
        model = result['models'][(r, phi)]
        target = model.event(phi, CRMS)['time']
        end = target if phi == 0 else min(target, float(native['time'][-1]))
        times = np.unique(np.r_[0., np.geomspace(1e-6, end, 500), np.linspace(0, end, 900)])
        ax.plot(native['time']/1e5, native['height'], color=color, lw=1.05, alpha=.8)
        marks = base.marker_indices(python['time'], python['height'])
        ax.plot(python['time'][marks]/1e5, python['height'][marks], color=color,
                ls='none', marker=marker, markerfacecolor='white', ms=4., zorder=3)
        ax.plot(times/1e5, model.prediction(times, phi, CRMS), color=color, ls='--', lw=1.8, zorder=4)
    last = max((result['models'][(c['ratio'], phi)].event(phi, CRMS)['time'] if phi == 0 else
                c['records']['jam']['time'][-1]) for c in group_cases)
    ax.set(xlabel=r'$t^*/10^5$', ylabel=r'$h_{\min}/h_0$', xlim=(-.012*last/1e5, 1.04*last/1e5),
           ylim=(0, .96), yticks=[.05, .2, .4, .6, .8], yticklabels=['0.05', '0.2', '0.4', '0.6', '0.8'])
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
    ax.axhline(.05, color='.45', lw=1., ls=':')
    ax.grid(False, which='both')
    legend_thickness(fig)
    fig.text(.56, .78, title+rf', $C_{{\rm rms}}={CRMS}$', ha='center')
    method = 'Initial spectrum' if phi == 0 else 'TCW + mode'
    handles = [Line2D([], [], color='black', label='Basilisk C'),
               Line2D([], [], color='black', ls='none', marker='o', markerfacecolor='white', label='Python/FFT'),
               Line2D([], [], color='black', ls='--', label=method)]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.56, .005),
               ncols=2, columnspacing=.8, handlelength=1.3, labelspacing=.15)
    base.save(fig, out, 'prediction_overlay_'+stem, book)


def forecast(cases, result, group, out, book):
    phi, title, stem = group
    fig, ax = plt.subplots()
    fig.subplots_adjust(left=.16, right=.96, bottom=.29, top=.75)
    group_cases = sorted((c for c in cases if c['theta'] == phi), key=lambda c: c['ratio'])
    for case, color, marker in zip(group_cases, COLORS, MARKERS):
        model = result['models'][(case['ratio'], phi)]
        end = model.event(phi, CRMS)['time']
        split = min(model.switch, end) if np.isfinite(model.switch) else end
        first = np.geomspace(1e-4, split, 420)
        ax.plot(first, model.prediction(first, phi, CRMS), color=color, lw=1.6)
        if split < end:
            second = np.geomspace(split, end, 420)
            ax.plot(second, model.prediction(second, phi, CRMS), color=color, ls='--', lw=1.7)
            ax.plot(split, model.prediction(split, phi, CRMS), color=color, marker='s', ms=4.5)
        native = case['records']['basilisk']
        selected = np.unique(np.searchsorted(native['time'], np.geomspace(
            max(native['time'][1], 1e-4), native['time'][-1], 16)))
        ax.plot(native['time'][selected], native['height'][selected], color=color, ls='none',
                marker=marker, markerfacecolor='white', ms=4., zorder=3)
    last = max(result['models'][(c['ratio'], phi)].event(phi, CRMS)['time'] for c in group_cases)
    ax.set(xscale='log', xlabel=r'$t^*$', ylabel=r'$h_{\min}/h_0$',
           xlim=(1e-3, 10**np.ceil(np.log10(last))), ylim=(0, .96),
           yticks=[.05, .2, .4, .6, .8], yticklabels=['0.05', '0.2', '0.4', '0.6', '0.8'])
    ax.axhline(.05, color='.45', ls=':', lw=1.)
    ax.grid(False, which='both')
    legend_thickness(fig)
    fig.text(.56, .78, title+rf', $C_{{\rm rms}}={CRMS}$', ha='center')
    handles = [Line2D([], [], color='black', label='TCW'),
               Line2D([], [], color='black', ls='--', label='Normal mode'),
               Line2D([], [], color='black', marker='s', ls='none', label='Match'),
               Line2D([], [], color='black', marker='o', markerfacecolor='white', ls='none', label='Basilisk C')]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.56, .005),
               ncols=2, columnspacing=.9, labelspacing=.15, handlelength=1.3)
    base.save(fig, out, 'prediction_forecast_'+stem, book)


def rupture_reference(cases, result, out, book):
    fig, ax = plt.subplots()
    fig.subplots_adjust(left=.16, right=.96, bottom=.29, top=.78)
    times = []
    for (phi, title, key), color in zip(GROUPS, COLORS):
        predicted = [row[key] for row in result['dense']]
        ax.plot(predicted, [row['ratio'] for row in result['dense']], color=color, ls='--', lw=1.6)
        times.extend(predicted)
        for case in (c for c in cases if c['theta'] == phi):
            for solver, size, fill in (('basilisk', 4., color), ('jam', 10., 'none')):
                row = case['records'][solver]['record']
                if row['event_observed']:
                    ax.plot(row['t_r'], case['ratio'], marker='o', ls='none', color=color,
                            markerfacecolor=fill, ms=size, zorder=3)
            row = case['records']['jam']['record']
            if not row['event_observed']:
                bound = row['t_r_lower_bound']
                ax.plot(bound, case['ratio'], color=color, marker='|', ms=12, mew=1.5)
                ax.annotate('', xy=(1.55*bound, case['ratio']), xytext=(bound, case['ratio']),
                            arrowprops=dict(arrowstyle='->', color=color, linewidth=1.5))
                times.append(bound)
    ax.set(xscale='log', xlabel=r'$t^*_{\rm r}$', ylabel=r'$h_{\rm i}/h_0$',
           xlim=(10**np.floor(np.log10(min(times)/1.5)), 10**np.ceil(np.log10(max(times)*1.3))),
           ylim=(.46, .95), yticks=list(RATIOS))
    ax.grid(False, which='both')
    fig.legend(handles=[Line2D([], [], color=c, label=g[1]) for g, c in zip(GROUPS, COLORS)],
               loc='upper center', bbox_to_anchor=(.56, .995), ncols=2,
               columnspacing=.8, handlelength=1.3, labelspacing=.1)
    fig.text(.56, .81, rf'$C_{{\rm rms}}={CRMS},\quad h_{{\min}}/h_0\leq0.05$', ha='center')
    handles = [Line2D([], [], color='black', ls='--', label='Reference'),
               Line2D([], [], color='black', marker='o', ls='none', markerfacecolor='none', ms=9, label='Python/FFT'),
               Line2D([], [], color='black', marker='o', ls='none', ms=4, label='Basilisk C'),
               Line2D([], [], color='black', marker='>', label='Lower bound')]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.56, .005), ncols=2,
               columnspacing=1., handlelength=1.3, labelspacing=.15)
    base.save(fig, out, 'thickness_vs_predicted_time', book)


def main():
    data = Path((ROOT/'plot_data_path.txt').read_text())
    out = ROOT/'prediction'
    out.mkdir(exist_ok=True)
    snapshot, cases, _ = base.read_data(data)
    result = analyze(cases, data)
    for key in ('events', 'scores', 'field_checks', 'curves', 'dense'):
        export_csv(out/(key+'.csv'), result[key])
    result['validation'].update(crms=CRMS, snapshot_utc=snapshot['ended_utc'],
        reference_chat='01a1c396-1915-7e23-99db-81bd4c9bf3e4',
        reference_source_sha256=hashlib.sha256(Path('F:/气泡夹断/free-film-rupture/postprocess/free_gap_tcw_normal.py').read_bytes()).hexdigest())
    (out/'validation.json').write_text(json.dumps(result['validation'], indent=2))
    base.apply_academic_style()
    with PdfPages(out/'wall_tcw_prediction.pdf') as book:
        rupture_reference(cases, result, out, book)
        for group in GROUPS:
            overlay(cases, result, group, out, book)
        for group in GROUPS[1:]:
            forecast(cases, result, group, out, book)
    print(json.dumps(dict(events=result['events'], scores=result['scores'], field_checks=result['field_checks']), indent=2))


if __name__ == '__main__':
    main()
