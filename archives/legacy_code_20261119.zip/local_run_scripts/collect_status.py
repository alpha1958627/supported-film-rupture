"""Read-only SIPF status audit; run by piping this file to the remote Python."""
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess

import numpy as np

ROOT = Path('/public/home/ljh/wall_rupture128_20261111.ht1uyCX4')
SLURM = '/opt/gridview/slurm/bin/'


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def last_record(path):
    with path.open('rb') as stream:
        header = stream.readline().decode().strip()
        stream.seek(0, 2)
        stream.seek(max(0, stream.tell() - 8192))
        tail = stream.read()
    lines = tail.split(b'\n')[:-1]
    row = next(csv.DictReader(io.StringIO(header + '\n' + lines[-1].decode())))
    return {key: float(value) for key, value in row.items()}


source_hashes = {}
for line in (ROOT / 'source_sha256.txt').read_text().splitlines():
    expected, relative = line.split(None, 1)
    relative = relative.lstrip('* ')
    actual = digest(ROOT / relative)
    assert actual == expected, relative
    source_hashes[relative] = actual

report = dict(snapshot_utc=datetime.now(timezone.utc).isoformat(),
              remote_root=str(ROOT), source_hashes_verified=source_hashes,
              cases=[])
for name, arguments in [
        ('squeue', ['-j', '62105', '-r', '-h', '-o', '%i|%T|%M|%N|%R']),
        ('sacct', ['-j', '62105', '-X', '-n', '-P',
                   '--format=JobID,State,Elapsed,Start,End,NodeList,ExitCode'])]:
    report[name] = subprocess.check_output([SLURM + name] + arguments).decode().strip()

for spec in json.loads((ROOT / 'cases.json').read_text()):
    folder = ROOT / 'cases' / spec['name']
    latest = json.loads((folder / 'latest.json').read_text())
    current = json.loads((folder / 'current.json').read_text())
    checkpoint = ROOT / latest['output']
    assert ROOT in checkpoint.resolve().parents
    summary = json.loads((checkpoint / 'summary.json').read_text())
    config = json.loads((checkpoint / 'config.json').read_text())
    assert config['initial_over_h0'] == spec['ratio']
    assert config['theta_at_h0'] == spec['theta']
    assert config['noise'] == spec['noise']
    assert config['grid'] == 128 and config['threshold_over_h0'] == .05
    assert config['model'] == 'supported_no_slip'
    assert config['mobility'] == 'frozen at the initial flat thickness'
    assert latest['t_ref'] == summary['t_ref']
    assert digest(checkpoint / 'history.csv') == summary['history_sha256']
    field_checks = {}
    with np.load(str(checkpoint / 'fields.npz')) as fields:
        for label in ('jam', 'basilisk'):
            final = fields[label + '_final']
            before = fields[label + '_before']
            assert final.shape == (128, 128) and np.isfinite(final).all()
            assert final.min() > 0 and abs(final.mean() - spec['ratio']) < 2e-12
            assert abs(final.min() - summary[label + '_hmin_h0']) < 1e-12
            field_checks[label] = dict(minimum=float(final.min()),
                                       mean=float(final.mean()))
            if label in summary['crossing']:
                crossing = summary['crossing'][label]
                assert before.min() > .05 and .0499 <= final.min() <= .05
                assert crossing['t_before'] < crossing['t_after'] <= summary['t_ref']
                assert abs(crossing['hmin_after'] - final.min()) < 1e-12
                field_checks[label]['before_minimum'] = float(before.min())
    if summary['status'] == 'threshold':
        assert set(summary['crossing']) == {'jam', 'basilisk'}
    live_folder = ROOT / current['output']
    history = live_folder / 'history.csv'
    if not history.exists():
        history = checkpoint / 'history.csv'
    entry = dict(spec, latest=latest, current=current, live=last_record(history),
                 config=config, field_checks=field_checks,
                 history_mtime_utc=datetime.fromtimestamp(
                     history.stat().st_mtime, timezone.utc).isoformat(),
                 checkpoint_verified=True)
    report['cases'].append(entry)
report['audit_completed_utc'] = datetime.now(timezone.utc).isoformat()
print(json.dumps(report, separators=(',', ':')))
