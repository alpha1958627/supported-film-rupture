"""Append editable wall predictions to a copy of the reviewed notebook."""
import ast
import hashlib
import json
from pathlib import Path
import textwrap

import nbformat as nbf

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
canonical = REPO/'postprocess/附壁液膜.ipynb'
notebook = nbf.read(canonical, as_version=4)
assert 'wall_prediction_reference' not in notebook.metadata
original_sha = hashlib.sha256(canonical.read_bytes()).hexdigest()


def definitions(path):
    source = path.read_text(encoding='utf-8')
    return {node.name: ast.get_source_segment(source, node) for node in ast.parse(source).body
            if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


def md(text):
    notebook.cells.append(nbf.v4.new_markdown_cell(textwrap.dedent(text).strip()))


def code(text, hidden=False):
    metadata = {'jupyter': {'source_hidden': True}} if hidden else {}
    notebook.cells.append(nbf.v4.new_code_cell(textwrap.dedent(text).strip(), metadata=metadata))


for cell in notebook.cells:
    cell.source = cell.source.replace('JAM/Basilisk', 'Python/FFT与Basilisk C').replace('JAM', 'Python/FFT')
    if cell.cell_type == 'code':
        cell.outputs, cell.execution_count = [], None
notebook.cells[1].source += '\n\n**实现名称更正：** 原始字段 `jam` 是历史键名，本批实际为自写 `WallFilm2D`/NumPy FFT支路，未调用原版JAM核心；图中显示为Python/FFT。'

md(r"""
# TCW＋正则模时间预测

沿用[指定自由膜聊天](codex://threads/01a1c396-1915-7e23-99db-81bd4c9bf3e4)的固定系数与斜率匹配构造，
默认 $C_{\rm rms}=3.5$。以下重新使用附壁膜算子与本批128²白噪声，**不拟合轨迹或破碎时刻**。
数据仍是前面同一份14:54快照，未来段是参考模型外推。

完整推导见同目录[附壁液膜_TCW与正则模预测.md](附壁液膜_TCW与正则模预测.md)。
""")
md(r"""
## 附壁增长率与谱

令 $H=h/h_0=r+\eta$，$L=128$，$a_0=(2\pi/L)^2/3$，本批冻结迁移率给出

$$K(q;r)=\frac{r^3q^2}{3},\qquad
s_q=K(q;r)\left(\frac{3a_0}{r^4}-q^2\right),\qquad
\Omega=\max_{\boldsymbol q\ne0}s_q.$$

零模态固定；$\Omega$取周期盒允许的物理模态最大值。连续时间谱为

$$S_q(t)=S_{0q}e^{2s_qt}+\frac{\varphi K_q}{L^2}\frac{e^{2s_qt}-1}{s_q},\qquad
\sigma^2(t)=\sum_{q\ne0}S_q(t),$$

其中 $s_q=0$ 时分式取 $2t$。二维白噪声的总方差依赖最高波数；此处明确在当前128²观测模态上求和，
不是无限波数极限，也不加入自由膜64→128插值的滤波因子。FV空间诊断只替换差分符号，仍保留连续时间。
""")
md(r"""
## 斜率匹配与无热噪声初始谱

热组先用 $H_T=r-C\sigma(t)$，以 $\dot\sigma(t_s)/\sigma(t_s)=\Omega$ 的第一个正到非正根拼接：

$$H_{\rm ref}(t)=\begin{cases}r-C\sigma(t),&t\leq t_s,\\
r-C\sigma(t_s)e^{\Omega(t-t_s)},&t>t_s.\end{cases}$$

高度及一阶导数连续。若阈值在拼接后到达，$t_r=t_s+\Omega^{-1}\log[(r-H_c)/(C\sigma(t_s))]$；
若更早到达，保留TCW-only分支。

无热涨落组使用保存初态的实际 $S_{0q}$，传播其完整正则模谱。没有热强迫时一般没有上述有限拼接根，
因此不人为制造TCW前段。仍使用相同的 $r-C\sigma$ 极值近似。
""")
code("""
from scipy.optimize import brentq

LENGTH = 128.
N_GRID = 128
ATTRACTION = (2*np.pi/LENGTH)**2/3
CRMS = 3.5
RATIOS = (.5, .6, .7, .8, .9)
PRED_DIR = EXPORT_DIR/'prediction'
if EXPORT_FIGURES:
    PRED_DIR.mkdir(parents=True, exist_ok=True)
""")
model = definitions(REPO/'postprocess/wall_tcw_normal.py')
check = model['self_check'].replace("Path(__file__).resolve().parent.parent/'jam'", "REPO/'jam'")
assert '__file__' not in check
code(model['WallTCW']+'\n\n'+check, hidden=True)
plots = definitions(ROOT/'plot_prediction.py')
code(plots['export_csv']+'\n\n'+plots['analyze'], hidden=True)
code("""
prediction_result = analyze(cases, DATA)
display(Markdown(f'**预测自检通过。** 固定 Crms={CRMS}，拟合参数数目为0；'
                 '已核对方差导数、C1斜率、阈值根、初始谱、稳定单界面谱及实际FV增长率。'))
""")
md("## 预测时间表\n\n时间均为共同单位 $t^*$。实测列的 `>` 是观察下界；预测列是模型值，不是已完成时刻或墙钟小时。")
code(r"""
for phi, label, _ in GROUPS:
    display(Markdown('### '+label))
    headers = ['hi/h0', '拼接ts', '预测0.3', '预测0.2', '预测0.1', '预测0.05', '实测0.05或下界', '相对差(%)']
    table = '<table><tr>'+''.join('<th>'+html.escape(h)+'</th>' for h in headers)+'</tr>'
    for row in (r for r in prediction_result['events'] if r['phi']==phi):
        observed = (f'{row["observed_t_r"]:.3e}' if row['observed_t_r'] is not None else
                    f'> {row["observed_until"]:.3e}')
        values = [f'{row["ratio"]:.1f}', f'{row["switch"]:.3e}' if row['switch'] is not None else '—']
        values += [f'{row["predicted_t_"+str(target)]:.3e}' for target in (.3,.2,.1,.05)]
        values += [observed, f'{row["predicted_time_error_percent"]:+.1f}'
                   if row['predicted_time_error_percent'] is not None else '—']
        table += '<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in values)+'</tr>'
    display(HTML(table+'</table>'))
""")
code('\n\n'.join(plots[name].replace('base.save', 'save').replace('base.marker_indices', 'marker_indices')
                 for name in ('legend_thickness', 'overlay', 'forecast', 'rupture_reference')), hidden=True)
md("## 厚度–预测首达时间\n\n虚线为预测；圈/点为实际首达；箭头仍是未破碎下界。参考曲线不代表集合平均寿命。")
code('rupture_reference(cases, prediction_result, PRED_DIR, None)')
for index, title in enumerate(('无热涨落：初始谱参考与完整外推',
                               r'$\varphi=10^{-4}$：当前窗口与预测',
                               r'$\varphi=10^{-3}$：当前窗口与预测')):
    md('### '+title+'\n\n实线为Basilisk C，空心标记为Python/FFT，虚线为固定系数的最低厚度参考。')
    code(f'overlay(cases, prediction_result, GROUPS[{index}], PRED_DIR, None)')
for index, title in ((1, r'$\varphi=10^{-4}$：完整TCW＋正则模预测'),
                     (2, r'$\varphi=10^{-3}$：完整TCW＋正则模预测')):
    md('### '+title+'\n\n本图横轴为对数时间。实线为TCW，虚线为指数正则模段，方块为匹配点；空心点只取实际计算时刻。')
    code(f'forecast(cases, prediction_result, GROUPS[{index}], PRED_DIR, None)')
md("## 当前对照能说明什么\n\n误差按物理时间加权，避免把大量自适应小步当成更多独立样本。原场RMS检查与拼接曲线误差分开；检查点场的时间未冒充最后观察时刻。")
code(r"""
known = [r['predicted_time_error_percent'] for r in prediction_result['events']
         if r['predicted_time_error_percent'] is not None]
display(Markdown(f'**已完成{len(known)}组的预测时间相对差：{min(known):+.1f}%到{max(known):+.1f}%。** '
                 '此差尚未独立分离模型近似与数值误差，不能据此声称精确寿命预测已验证。'))
for phi, label, _ in GROUPS:
    rows = [r for r in prediction_result['scores'] if r['phi']==phi]
    rmse = [r['time_RMSE'] for r in rows]
    display(Markdown(f'{label}：当前窗口的时间加权RMSE为 {min(rmse):.4f}–{max(rmse):.4f} $h_0$。'))
thermal_events = [r for r in prediction_result['events'] if r['phi']>0]
after = sum(r['switch'] is not None and r['observed_until']>r['switch'] for r in thermal_events)
display(Markdown(f'10个热组中，{after}个观察窗口已越过参考模型的拼接时刻；'
                 '这不证明模拟形态已成为单模。热组尚无实测破碎时间，最终寿命仍待后期轨迹检验。'))
contradicted = [r for r in thermal_events if r['observation_outlives_forecast']]
if contradicted:
    display(Markdown('**已有未破碎观察超出模型预测时间；相应预测已受数据反驳，不能当成剩余时间。**'))
""")
md("## 预测导出与来源\n\n固定Crms、谱截止和指数尾段都是明确的参考假设。原始数据、首达与下界保留；不把单条路径或参考曲线解释为平均破碎时间。SciPy是本节新增依赖。")
code(r"""
prediction_order = ['thickness_vs_predicted_time', 'prediction_overlay_initial',
                    'prediction_overlay_phi0001', 'prediction_overlay_phi001',
                    'prediction_forecast_phi0001', 'prediction_forecast_phi001']
assert set(FIGURES) == set(figure_order+prediction_order)
if EXPORT_FIGURES:
    for name in ('events', 'scores', 'field_checks', 'curves', 'dense'):
        export_csv(PRED_DIR/(name+'.csv'), prediction_result[name])
    with PdfPages(PRED_DIR/'附壁膜_TCW预测.pdf') as book:
        for name in prediction_order:
            book.savefig(FIGURES[name])
    with PdfPages(EXPORT_DIR/'附壁液膜_含预测.pdf') as book:
        for name in figure_order+prediction_order:
            book.savefig(FIGURES[name])
    (PRED_DIR/'validation.json').write_text(json.dumps(prediction_result['validation'], indent=2), encoding='utf-8')
    display(Markdown(f'**已导出6幅预测图、12页完整合集与预测CSV：** `{PRED_DIR}`'))
""")
notebook.metadata['wall_prediction_reference'] = dict(
    chat='01a1c396-1915-7e23-99db-81bd4c9bf3e4', crms=3.5, parameters_fitted=0,
    observation_cutoff=128, raw_solver_field='jam', actual_solver_label='Python/FFT',
    original_notebook_sha256=original_sha)
nbf.validate(notebook)
candidate = ROOT/'notebook_prediction_candidate.ipynb'
nbf.write(notebook, candidate)
(ROOT/'notebook_update_receipt.json').write_text(json.dumps(dict(
    canonical=str(canonical), candidate=str(candidate), original_sha256=original_sha), indent=2), encoding='utf-8')
print('candidate cells', len(notebook.cells), 'code', sum(c.cell_type == 'code' for c in notebook.cells))
