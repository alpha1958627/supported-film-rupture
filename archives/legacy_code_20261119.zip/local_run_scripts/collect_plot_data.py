"""Copy a fixed, complete-line prefix of each live history without touching jobs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
import tempfile


ROOT = Path('/public/home/ljh/wall_rupture128_20261111.ht1uyCX4')
out = Path(tempfile.mkdtemp(prefix='wall_plot_snapshot_'+datetime.now(timezone.utc).strftime('%Y%m%d')+'.', dir='/public/home/ljh'))
capture = dict(started_utc=datetime.now(timezone.utc).isoformat(), remote_root=str(ROOT),
               job=62105, cases=[], source_verified={})
for line in (ROOT/'source_sha256.txt').read_text().splitlines():
    digest, name = line.split(None, 1)
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, name
    capture['source_verified'][name] = digest

for case in json.loads((ROOT/'cases.json').read_text()):
    base = ROOT/'cases'/case['name']
    current = json.loads((base/'current.json').read_text())
    latest = json.loads((base/'latest.json').read_text())
    source = ROOT/current['output']
    prior = ROOT/latest['output']
    target = out/'cases'/case['name']
    target.mkdir(parents=True)
    # A writer can append while copying. The fixed byte count prevents mixing times.
    with (source/'history.csv').open('rb') as reader, (target/'history.csv').open('wb') as writer:
        reader.seek(0, 2)
        size = reader.tell()
        reader.seek(max(0, size-4096))
        tail = reader.read(size-reader.tell())
        size -= len(tail)-tail.rfind(b'\n')-1
        reader.seek(0)
        remaining = size
        while remaining:
            data = reader.read(min(1024*1024, remaining))
            assert data
            writer.write(data)
            remaining -= len(data)
    prior_size = (prior/'history.csv').stat().st_size
    digest = hashlib.sha256()
    remaining = prior_size
    with (target/'history.csv').open('rb') as reader:
        while remaining:
            data = reader.read(min(1024*1024, remaining))
            assert data, case['name']
            digest.update(data)
            remaining -= len(data)
    assert digest.hexdigest() == latest['history_sha256'], case['name']
    shutil.copyfile(str(source/'config.json'), str(target/'config.json'))
    shutil.copyfile(str(prior/'fields.npz'), str(target/'checkpoint_fields.npz'))
    (target/'checkpoint_summary.json').write_text(json.dumps(latest, indent=2))
    if (source/'summary.json').exists():
        shutil.copyfile(str(source/'summary.json'), str(target/'current_summary.json'))
    capture['cases'].append(dict(case, current=current, checkpoint=latest,
                                 history_prefix_bytes=prior_size,
                                 captured_history_bytes=size,
                                 current_history_source=str(source/'history.csv'),
                                 checkpoint_fields_source=str(prior/'fields.npz'),
                                 captured_utc=datetime.now(timezone.utc).isoformat()))

capture['ended_utc'] = datetime.now(timezone.utc).isoformat()
(out/'snapshot.json').write_text(json.dumps(capture, indent=2))
files = sorted(path for path in out.rglob('*') if path.is_file())
(out/'manifest.sha256').write_text(''.join(
    hashlib.sha256(path.read_bytes()).hexdigest()+'  '+path.relative_to(out).as_posix()+'\n'
    for path in files))
archive = Path(str(out)+'.tar.gz')
with tarfile.open(str(archive), 'w:gz', compresslevel=1) as tar:
    for path in sorted(out.rglob('*')):
        if path.is_file():
            tar.add(str(path), arcname=path.relative_to(out).as_posix())
print(json.dumps(dict(directory=str(out), archive=str(archive),
                      archive_bytes=archive.stat().st_size,
                      sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                      captured_utc=capture['ended_utc']), separators=(',', ':')))
