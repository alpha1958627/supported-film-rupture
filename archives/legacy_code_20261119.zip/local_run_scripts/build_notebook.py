"""Package the reviewed plotting format as an editable, executable notebook."""
import ast
import hashlib
from pathlib import Path
import textwrap

import nbformat as nbf


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
destination = REPO/'postprocess'/'附壁液膜.ipynb'
source = (ROOT/'plot_progress.py').read_text(encoding='utf-8')
tree = ast.parse(source)
functions = {node.name: ast.get_source_segment(source, node) for node in tree.body
             if isinstance(node, ast.FunctionDef)}
style_path = Path('C:/Users/Administrator/.agents/skills/matplotlib-academic-figures/scripts/academic_style.py')
style_source = style_path.read_text(encoding='utf-8')
style_tree = ast.parse(style_source)
style_functions = {node.name: ast.get_source_segment(style_source, node)
                   for node in style_tree.body if isinstance(node, ast.FunctionDef)}
cells = []


def md(text):
    cells.append(nbf.v4.new_markdown_cell(textwrap.dedent(text).strip()))


def code(text, hidden=False):
    metadata = {'jupyter': {'source_hidden': True}} if hidden else {}
    cells.append(nbf.v4.new_code_cell(textwrap.dedent(text).strip(), metadata=metadata))


md(r"""
# 附壁液膜

保存已核对的 **初始厚度–破碎时间** 与 **最低厚度–时间** 绘图格式。

默认数据为北京时间 **2026-11-11 14:54:04** 的固定快照：15组成对JAM/Basilisk轨迹，
4组已跨破碎阈值、11组仍在观察，共3,522,026行历史记录。
打开本文件即可查看已执行输出；修改参数后从上到下运行即可复画。
""")
md(r"""
## 方法与坐标

- 网格 $128^2$，本批迁移率冻结在初始平膜；破碎判据为 $h_{\min}/h_0\leq0.05$。
- 无热涨落组初始有1% RMS随机扰动；$\varphi=10^{-4},10^{-3}$ 两档从平膜起步，持续加噪。
- 厚度–破碎时间图：横轴 $t_{\rm r}^*$ 为对数，纵轴 $h_{\rm i}/h_0$ 为线性。
  圈/点表示JAM/Basilisk各自实际首达，向右箭头表示 $t_{\rm r}>t_{\rm obs}$。
- 最低厚度历史：横轴 $t^*/10^5$，纵轴 $h_{\min}/h_0$，均为线性。
  三档全程图使用相同范围，另给热组时间窗口放大图。每条轨迹停在自身首次跨阈值或观察终点。
- 每个工况只有一对轨迹，图中不是集合平均破碎时间；运行项不补造破碎值。

图面固定为8×6英寸、20pt真实LaTeX、无网格，黑/红/蓝优先配色，并以标记区分厚度。
""")
md("## 参数与数据\n\n数据读取均为本地文件。后续换用另一份已保存快照时，只需修改下面的 `SNAPSHOT_NAME`。")
code(r"""
%matplotlib inline
from matplotlib_inline.backend_inline import InlineBackend, set_matplotlib_formats
set_matplotlib_formats('png')
InlineBackend.instance().print_figure_kwargs = {'bbox_inches': None}

import csv
import hashlib
import html
import json
from pathlib import Path
import shutil

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
import numpy as np
from IPython.display import display, HTML, Markdown

RUN_NAME = 'rupture_128_20261111'
SNAPSHOT_NAME = 'plot_snapshot_20261111T065404Z'
EXPORT_FIGURES = True

candidates = [Path.cwd(), Path.cwd().parent, Path.cwd().parent.parent,
              Path.cwd()/'supported-film-rupture']
REPO = next((p for p in candidates if (p/'runs'/RUN_NAME/SNAPSHOT_NAME).is_dir()), None)
assert REPO is not None, '请从supported-film-rupture仓库或其postprocess目录运行，并保留原数据目录。'
DATA = REPO/'runs'/RUN_NAME/SNAPSHOT_NAME
EXPORT_DIR = REPO/'runs'/RUN_NAME/'notebook_exports'
if EXPORT_FIGURES:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
FIGURES = {}
""")
style = "FIGSIZE = (8., 6.)\nFONT_SIZE = 20.\nSTYLE_COLORS = ('#000000', '#D62728', '#1F77B4')\n\n"
style += '\n\n'.join(style_functions[name].replace('COLORS', 'STYLE_COLORS')
                      for name in ('require_latex', 'apply_academic_style', 'validate_active_style'))
style += "\n\napply_academic_style()\nvalidate_active_style()\nmpl.rcParams['figure.dpi'] = 150\n"
style += "\nCOLORS = ('#000000', '#D62728', '#1F77B4', '#9467BD', '#2CA02C')\n"
style += "MARKERS = ('o', 's', '^', 'D', 'v')\n"
style += "GROUPS = ((0., 'Initial perturbation only', 'initial'),\n          (.0001, r'$\\varphi=10^{-4}$', 'phi0001'),\n          (.001, r'$\\varphi=10^{-3}$', 'phi001'))"
code(style, hidden=True)
md("### 数据校验\n\n核对文件SHA、完整检查点前缀、初始扰动、原场体积与最低厚度，以及每个求解器的首次跨阈值。下方函数可展开编辑。")
code(functions['read_data'], hidden=True)
code(r"""
for line in (DATA/'manifest.sha256').read_text().splitlines():
    digest, name = line.split(None, 1)
    assert hashlib.sha256((DATA/name).read_bytes()).hexdigest() == digest, name

snapshot, cases, events = read_data(DATA)
completed = sum(all(c['records'][s]['record']['event_observed'] for s in ('jam', 'basilisk'))
                for c in cases)
history_rows = sum(c['history_rows'] for c in cases)
FULL_TIME_RIGHT = float(np.ceil(max(c['records']['jam']['time'][-1] for c in cases)/1e6)*10)
display(Markdown(f'**输入核对通过：{len(cases)}组，{completed}组完成、{len(cases)-completed}组在观察；'
                 f'{history_rows:,}行历史。快照UTC：`{snapshot["ended_utc"]}`。'))
""")
code(r"""
headers = ['phi', 'hi/h0', '状态', 'JAM tr或下界', 'Basilisk tr或下界',
           'JAM末值hmin/h0', 'Basilisk末值hmin/h0']
table = '<table><thead><tr>'+''.join('<th>'+h+'</th>' for h in headers)+'</tr></thead><tbody>'
for case in cases:
    j, b = (case['records'][s]['record'] for s in ('jam', 'basilisk'))
    def time_text(record):
        return (f'{record["t_r"]:,.6f}' if record['event_observed'] else
                f'> {record["t_r_lower_bound"]:,.6f}')
    values = [f'{case["theta"]:g}', f'{case["ratio"]:g}',
              '完成' if j['event_observed'] and b['event_observed'] else '观察中',
              time_text(j), time_text(b), f'{j["last_hmin_h0"]:.6f}', f'{b["last_hmin_h0"]:.6f}']
    table += '<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in values)+'</tr>'
display(HTML(table+'</tbody></table>'))
""")
md("## 绘图格式\n\n下面保留全部可编辑绘图函数；与刚才确认的图使用相同轴定义、线型、图例和下界箭头。每个结果图各占一个代码单元。")
save = r"""
def save(fig, out, stem, book=None):
    FIGURES[stem] = fig
    if EXPORT_FIGURES:
        fig.savefig(out/(stem+'.pdf'))
        fig.savefig(out/(stem+'.png'), dpi=600)
    if book is not None:
        book.savefig(fig)
    display(fig)
    plt.close(fig)
"""
code(save+'\n\n'+ '\n\n'.join(functions[name] for name in
                              ('rupture_plot', 'marker_indices', 'history_plot')), hidden=True)
md(r"""
### 初始厚度–破碎时间

黑色已破碎点来自无热涨落组的 $h_{\rm i}/h_0=0.5,0.6,0.7,0.8$。
其余11组的箭头只表示时间下界，不能据此判定热涨落组的最终破碎时间更短。
""")
code('rupture_plot(cases, EXPORT_DIR, None)')
for index, title in enumerate(('无热涨落：统一全程坐标',
                               r'$\varphi=10^{-4}$：统一全程坐标',
                               r'$\varphi=10^{-3}$：统一全程坐标')):
    md('### '+title)
    code(f'history_plot(cases, GROUPS[{index}], EXPORT_DIR, None, FULL_TIME_RIGHT)')
for index, title in ((1, r'$\varphi=10^{-4}$：时间窗口放大'),
                     (2, r'$\varphi=10^{-3}$：时间窗口放大')):
    md('### '+title+'\n\n仅改变横轴显示范围；时间单位、纵轴范围与原始历史均保持一致。')
    code(f"last_time = max(c['records']['jam']['time'][-1] for c in cases if c['theta'] == GROUPS[{index}][0])\n"
         f"history_plot(cases, GROUPS[{index}], EXPORT_DIR, None, 1.05*last_time/1e5, zoom=True)")
md("## 导出与复算\n\n`EXPORT_FIGURES=True` 时导出单图PDF、600dpi PNG、六页合集及首达/下界CSV。修改已确认的格式或快照参数后，从上到下重运行即可。")
code(r"""
figure_order = ['thickness_vs_rupture_time', 'hmin_vs_time_initial_full',
                'hmin_vs_time_phi0001_full', 'hmin_vs_time_phi001_full',
                'hmin_vs_time_phi0001_zoom', 'hmin_vs_time_phi001_zoom']
assert set(FIGURES) == set(figure_order)
assert sum(row['event_observed'] for row in events) == 2*completed
assert all(row['t_r'] is None and row['t_r_lower_bound'] > 0
           for row in events if not row['event_observed'])
for fig in FIGURES.values():
    assert tuple(fig.get_size_inches()) == (8., 6.)
    assert all(not line.get_visible() for ax in fig.axes for line in ax.get_xgridlines()+ax.get_ygridlines())

if EXPORT_FIGURES:
    with PdfPages(EXPORT_DIR/'附壁液膜.pdf') as book:
        for name in figure_order:
            book.savefig(FIGURES[name])
    with (EXPORT_DIR/'rupture_times.csv').open('w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=list(events[0]))
        writer.writeheader()
        writer.writerows(events)
    display(Markdown(f'**六张图已导出：** `{EXPORT_DIR}`'))
""")
md(r"""
## 当前快照结论

- 无热涨落组的0.5–0.8四个厚度已经达到本批0.05判据，0.9组仍在观察。
- 两档热涨落组尚未达到该判据；图中保留实际涨落及不同观察时间，未平滑、补造或外推破碎点。
- 这份Notebook保存当前格式与固定快照，不会自动连接服务器或改变任务。

依赖：Python、NumPy、Matplotlib、IPython/Jupyter及系统LaTeX（latex、dvipng、dvips）。
数据目录为仓库内 `runs/rupture_128_20261111/plot_snapshot_20261111T065404Z`；
原图参考与来源保存在同一运行目录的 `figures/README.md`、`plot_summary.json` 和快照清单中。
""")
notebook = nbf.v4.new_notebook(cells=cells, metadata={
    'kernelspec': {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'},
    'language_info': {'name': 'python'},
    'wall_film_snapshot': '2026-11-11T06:54:04.653800+00:00',
    'reviewed_plot_source_sha256': hashlib.sha256(source.encode()).hexdigest(),
})
nbf.validate(notebook)
if destination.exists():
    raise FileExistsError('Preserve the existing notebook: '+str(destination))
nbf.write(notebook, destination)
print(destination)
print('cells', len(cells), 'code', sum(c.cell_type == 'code' for c in cells))
