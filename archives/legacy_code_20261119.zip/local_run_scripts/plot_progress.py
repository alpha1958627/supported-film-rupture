"""Plot the 15-case wall-film snapshot, preserving first passages and censoring."""
import csv
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
import numpy as np

sys.path.insert(0, 'C:/Users/Administrator/.agents/skills/matplotlib-academic-figures/scripts')
from academic_style import apply_academic_style, validate_active_style

ROOT = Path(__file__).resolve().parent
COLORS = ('#000000', '#D62728', '#1F77B4', '#9467BD', '#2CA02C')
MARKERS = ('o', 's', '^', 'D', 'v')
GROUPS = ((0., 'Initial perturbation only', 'initial'),
          (.0001, r'$\varphi=10^{-4}$', 'phi0001'),
          (.001, r'$\varphi=10^{-3}$', 'phi001'))


def read_data(data):
    snapshot = json.loads((data/'snapshot.json').read_text())
    assert len(snapshot['cases']) == 15
    cases, events = [], []
    for metadata in snapshot['cases']:
        p = data/'cases'/metadata['name']
        config = json.loads((p/'config.json').read_text())
        cp = metadata['checkpoint']
        assert config['grid'] == 128 and config['length_over_h0'] == 128
        assert config['initial_over_h0'] == metadata['ratio']
        assert config['theta_at_h0'] == metadata['theta']
        assert config['threshold_over_h0'] == .05
        assert config['mobility'] == 'frozen at the initial flat thickness'
        with (p/'history.csv').open('rb') as file:
            assert hashlib.sha256(file.read(metadata['history_prefix_bytes'])).hexdigest() == cp['history_sha256']
        h = np.loadtxt(p/'history.csv', delimiter=',', skiprows=1)
        assert h.ndim == 2 and h.shape[1] == 7
        assert np.isfinite(h).all() and h[0, 0] == 0 and np.all(np.diff(h[:, 0]) > 0)
        checkpoint_index = int(np.searchsorted(h[:, 0], cp['t_ref']))
        assert checkpoint_index == cp['accepted'] and h[checkpoint_index, 0] == cp['t_ref']
        records = {}
        with np.load(p/'checkpoint_fields.npz') as z:
            initial = z['initial']
            assert abs(float(initial.mean())-metadata['ratio']) < 2e-12
            expected_rms = .01*metadata['ratio'] if metadata['noise'] == 'initial' else 0.
            assert abs(float(initial.std())-expected_rms) < 1e-12
            for solver, column in (('jam', 2), ('basilisk', 3)):
                final = z[solver+'_final']
                assert np.isfinite(final).all() and final.shape == (128, 128)
                assert abs(float(final.mean())-metadata['ratio']) < 2e-12
                assert abs(float(final.min())-h[checkpoint_index, column]) < 1e-12
                values = h[:, column]
                crossings = np.flatnonzero(values <= .05)
                row = dict(name=metadata['name'], initial_over_h0=metadata['ratio'],
                           phi=metadata['theta'], solver=solver, observed_until=float(h[-1, 0]),
                           event_observed=bool(len(crossings)), t_r_before=None, t_r=None,
                           t_r_lower_bound=None, last_hmin_h0=float(values[-1]))
                if len(crossings):
                    index = int(crossings[0])
                    assert index > 0 and values[index-1] > .05 and .0499 <= values[index] <= .05
                    event = cp['crossing'][solver]
                    assert h[index-1, 0] == event['t_before'] and h[index, 0] == event['t_after']
                    assert float(z[solver+'_before'].min()) > .05 and float(final.min()) <= .05
                    row.update(t_r_before=float(h[index-1, 0]), t_r=float(h[index, 0]))
                    end = index+1
                else:
                    assert solver not in cp['crossing']
                    row['t_r_lower_bound'] = float(h[-1, 0])
                    end = len(h)
                records[solver] = dict(time=h[:end, 0], height=h[:end, column], record=row)
                events.append(row)
        cases.append(dict(metadata, history_rows=len(h), records=records))
    return snapshot, cases, events


def save(fig, out, stem, book):
    fig.savefig(out/(stem+'.pdf'))
    fig.savefig(out/(stem+'.png'), dpi=600)
    book.savefig(fig)
    plt.close(fig)


def rupture_plot(cases, out, book):
    fig, ax = plt.subplots()
    fig.subplots_adjust(left=.16, right=.96, bottom=.25, top=.80)
    times = []
    for (phi, label, _), color in zip(GROUPS, COLORS):
        group = sorted((c for c in cases if c['theta'] == phi), key=lambda c: c['ratio'])
        completed = [c for c in group if c['records']['jam']['record']['event_observed']
                     and c['records']['basilisk']['record']['event_observed']]
        if completed:
            ax.plot([c['records']['basilisk']['record']['t_r'] for c in completed],
                    [c['ratio'] for c in completed], color=color, lw=1.25, zorder=1)
        for case in group:
            for solver, size, face in (('basilisk', 4., color), ('jam', 10., 'none')):
                row = case['records'][solver]['record']
                if row['event_observed']:
                    ax.plot(row['t_r'], case['ratio'], marker='o', ms=size,
                            markerfacecolor=face, markeredgecolor=color, ls='none', zorder=3)
                    times.append(row['t_r'])
            if not case['records']['jam']['record']['event_observed']:
                bound = case['records']['jam']['record']['t_r_lower_bound']
                ax.plot(bound, case['ratio'], marker='|', color=color, ms=12, mew=1.6)
                ax.annotate('', xy=(1.55*bound, case['ratio']), xytext=(bound, case['ratio']),
                            arrowprops=dict(arrowstyle='->', color=color, linewidth=1.6))
                times.append(bound)
    ax.set(xscale='log', xlabel=r'$t^*_{\rm r}$', ylabel=r'$h_{\rm i}/h_0$',
           xlim=(10**np.floor(np.log10(min(times)/1.5)),
                 10**np.ceil(np.log10(max(times)*1.8))),
           ylim=(.46, .95), yticks=[.5, .6, .7, .8, .9])
    ax.grid(False, which='both')
    group_handles = [Line2D([], [], color=color, label=label)
                     for (phi, label, _), color in zip(GROUPS, COLORS)]
    fig.legend(handles=group_handles, loc='upper center', bbox_to_anchor=(.56, .99),
               ncols=2, labelspacing=.1, handlelength=1.25, columnspacing=.8)
    fig.text(.56, .82, r'$128^2,\quad h_{\min}/h_0\leq0.05$', ha='center')
    handles = [Line2D([], [], color='black', marker='o', markerfacecolor='none',
                      ms=9, ls='none', label='JAM'),
               Line2D([], [], color='black', marker='o', ms=4, ls='none', label='Basilisk'),
               Line2D([], [], color='black', marker='>', ls='-', label='Lower bound')]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.56, .015),
               ncols=3, handlelength=1.2, columnspacing=.8, handletextpad=.3)
    save(fig, out, 'thickness_vs_rupture_time', book)


def marker_indices(time, height):
    marks = list(np.searchsorted(time, np.linspace(0., time[-1], 14)))
    for level in (.35, .18, .08):
        found = np.flatnonzero(height <= level)
        if len(found):
            marks.append(int(found[0]))
    return np.unique(marks+[0, len(time)-1])


def history_plot(cases, group, out, book, right, zoom=False):
    phi, title, stem = group
    fig, ax = plt.subplots()
    fig.subplots_adjust(left=.16, right=.96, bottom=.25, top=.75)
    handles = []
    group_cases = sorted((c for c in cases if c['theta'] == phi), key=lambda c: c['ratio'])
    for case, color, marker in zip(group_cases, COLORS, MARKERS):
        native, jam = case['records']['basilisk'], case['records']['jam']
        ax.plot(native['time']/1e5, native['height'], color=color, lw=1.15, zorder=2)
        ax.plot(jam['time']/1e5, jam['height'], color=color, ls='--', lw=.55,
                marker=marker, markevery=marker_indices(jam['time'], jam['height']),
                markerfacecolor='white', ms=4.5, zorder=3)
        handles.append(Line2D([], [], color=color, marker=marker, markerfacecolor='white',
                              label=rf'$h_{{\rm i}}/h_0={case["ratio"]}$'))
    ax.axhline(.05, color='.45', ls='--', lw=1., zorder=1)
    ax.set(xlabel=r'$t^*/10^5$', ylabel=r'$h_{\min}/h_0$',
           xlim=(-.012*right, right), ylim=(0, .96),
           yticks=[.05, .2, .4, .6, .8], yticklabels=['0.05', '0.2', '0.4', '0.6', '0.8'])
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
    ax.grid(False, which='both')
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.56, .995),
               ncols=3, columnspacing=.8, handlelength=1.2, handletextpad=.3, labelspacing=.15)
    fig.text(.56, .78, title+(' (zoom)' if zoom else ''), ha='center')
    methods = [Line2D([], [], color='black', marker='o', markerfacecolor='white',
                      ls='--', label='JAM'), Line2D([], [], color='black', label='Basilisk'),
               Line2D([], [], color='.45', ls='--', label=r'Threshold $0.05$')]
    fig.legend(handles=methods, loc='lower center', bbox_to_anchor=(.56, .015),
               ncols=3, handlelength=1.2, handletextpad=.3, columnspacing=.8)
    save(fig, out, 'hmin_vs_time_'+stem+('_zoom' if zoom else '_full'), book)


def main():
    data = Path(sys.argv[1]) if len(sys.argv) > 1 else Path((ROOT/'plot_data_path.txt').read_text())
    out = ROOT/'figures'
    out.mkdir(exist_ok=True)
    snapshot, cases, events = read_data(data)
    with (out/'rupture_times.csv').open('w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=list(events[0]))
        writer.writeheader()
        writer.writerows(events)
    apply_academic_style()
    validate_active_style()
    right = np.ceil(max(c['records']['jam']['time'][-1] for c in cases)/1e6)*10
    with PdfPages(out/'wall_film_progress.pdf') as book:
        rupture_plot(cases, out, book)
        for group in GROUPS:
            history_plot(cases, group, out, book, right)
        for group in GROUPS[1:]:
            last = max(c['records']['jam']['time'][-1] for c in cases if c['theta'] == group[0])
            history_plot(cases, group, out, book, 1.05*last/1e5, zoom=True)
    completed = sum(all(c['records'][s]['record']['event_observed'] for s in ('jam', 'basilisk')) for c in cases)
    report = dict(snapshot_utc=snapshot['ended_utc'], data=str(data), paired_cases=len(cases),
                  completed=completed, running=len(cases)-completed, threshold=.05,
                  raw_histories_rows=sum(c['history_rows'] for c in cases),
                  first_passage_events=sum(r['event_observed'] for r in events),
                  right_censored=sum(not r['event_observed'] for r in events),
                  hmin_full_xlim=[-.012*right, right], time_divisor=1e5,
                  thickness_plot_scales=['log', 'linear'], history_scales=['linear', 'linear'],
                  raw_fields_and_checkpoint_prefixes_verified=True,
                  free_film_reference='free-film-rupture/runs/rupture_128/plot_hmin_history.py; sweep/summarize_sweep.py')
    (out/'plot_summary.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
